import React, {useState, useEffect} from 'react';
import {BrowserRouter as Router, Route, Switch, Link} from 'react-router-dom';

import './App.css';
import Button from '@material-ui/core/Button';

import Step1 from './Steps/Step1';
import Step3 from './Steps/Step3';
import Step4 from './Steps/Step4';
import Step5 from './Steps/Step5';
import Step6 from './Steps/Step6';
import Step7 from './Steps/Step7';
import Step8 from './Steps/Step8';
import Step9 from './Steps/Step9';
import Step92 from './Steps/Step92';
import Step93 from './Steps/Step93';
import Step10 from './Steps/Step10';
import Step11 from './Steps/Step11';
import Step12 from './Steps/Step12';
import Step13 from './Steps/Step13';
import Step14 from './Steps/Step14';
import Step15 from './Steps/Step15';
import Step16 from './Steps/Step16';
import Step17 from './Steps/Step17';
import Step20 from './Steps/Step20';
import Step21 from './Steps/Step21';
import Stage1 from './Steps/Stage1';
import Stage2 from './Steps/Stage2';
import EndQuestionnaire from './Steps/EndQuestionnaire';
import EndQuestionnaire2 from './Steps/EndQuestionnaire2';
import EndQuestionnaire3 from './Steps/EndQuestionnaire3';
import Youtube from './Steps/Youtube';
import PracticeStage2 from './components/PracticeStage2';

import Modal from './Modal';
import LoginPanel from './LoginPanel';
import useKeypress from 'react-use-keypress';
import YoutubePlayer from './Steps/YoutubePlayer';

function App() {

  const [getTime, setGetTime] = React.useState('');
 
  function getSteps() {
    return ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''];
  }
  
  function getStepContent(stepIndex, setIsDisabled) {
    switch (stepIndex) {
        case 0:
        return <Step1 setTypeMsg= {setTypeMsg} setGoNext = {setGoNext} setIsDisabled={setIsDisabled}/>;
        case 2:
        return <Youtube setGoNext = {setGoNext} typeMsg = {typeMsg} setIsDisabled={setIsDisabled}/>;
        case 3:
        return <Step3 />;
        case 4:
        return <Step4 />;
        case 5:
        return <Step5 setGoNext = {setGoNext} setIsDisabled={setIsDisabled} handleNext= {handleNext}/>;
        case 6:
        return <Step6 index= "1"/>;
        case 7:
        return <Stage1 setGoNext = {setGoNext} setIsDisabled={setIsDisabled} handleNext = {handleNext} timerTask = {timerTask}/>;
        case 8:
        return <Step7 />;
        case 9:
        return <Step8 setGoNext = {setGoNext} setIsDisabled={setIsDisabled}/>;
        case 10:
        return <Step9 setGetTime= {setGetTime} setIsDisabled={setIsDisabled}/>;

        case 11:
        return <PracticeStage2 setGoNext = {setGoNext} setIsDisabled = {setIsDisabled} handleNext= {handleNext}/>;
        
        case 12:
        return <Step6 index= "2"/>;

        case 13:
        return <Step92 setGetTime= {setGetTime} setIsDisabled={setIsDisabled}/>;
        case 14:
        return <Step93 />;
        case 15:
        return <Step10 setGoNext = {setGoNext} setIsDisabled={setIsDisabled}/>;
        case 16:
        return <Step11 setGoNext = {setGoNext} setIsDisabled={setIsDisabled}/>;
        case 17:
        return <Step12 setGoNext = {setGoNext} setIsDisabled={setIsDisabled}/>;
        case 18:
        return <Step13 setGoNext = {setGoNext} setIsDisabled={setIsDisabled}/>;
        case 19:
        return <Step14 setGoNext = {setGoNext} setIsDisabled={setIsDisabled}/>;
        case 20:
        return <Step20 setGoNext = {setGoNext} setIsDisabled={setIsDisabled}/>;
        case 21:
        return <Step15 setGoNext = {setGoNext} setIsDisabled={setIsDisabled}/>;
        case 22:
        return <Step16 setGoNext = {setGoNext} setIsDisabled={setIsDisabled}/>;
        case 23:
        return <Step17 setGoNext = {setGoNext} setIsDisabled={setIsDisabled}/>;
        case 24:
        return <Stage2 setGoNext = {setGoNext} setIsDisabled={setIsDisabled} handleNext= {handleNext} timerTask2 = {timerTask2}/>;
        case 25:
        return <EndQuestionnaire setGoNext = {setGoNext} setIsDisabled={setIsDisabled}/>;
        case 26:
        return <EndQuestionnaire2 setGoNext = {setGoNext}/>;      
        case 27:
        return <Step21 setGoNext = {setGoNext}/>;        

      default:
        return '';
    }
  }

  const [openF10, setOpenF10] = useState(false);
  const [goNext, setGoNext] = useState(false);
  const [typeMsg, setTypeMsg] = useState(false);

  const [isPrevDisabled, setIsPrevDisabled] = React.useState(false);
  const steps = getSteps();
  const [isOpened, setIsOpened] = React.useState(false);

  const [activeStep, setActiveStep] = useState(0);
  const [isDisabled, setIsDisabled] = useState(true);
 
  const timerTask = React.useRef();
  const timerTask2 = React.useRef();

  let date1 = new Date();

  const downHandler = () => {
        
   if(document.visibilityState === 'visible') {    
     
      document.title = 'Transcription Task';      
   } 
   else 
    {
      date1 = new Date();
      document.title = 'Transcription Task';                
    }
  }

  const popstateHandler = (e) => {
    try{
      this.props.history.go(1);
    }catch{}
  }

  React.useEffect(() => {
    
    if(!window.location.href.includes('youtubeplayer')) {
      localStorage.clear();

      localStorage.setItem('durationview2YTPractice', 0);
      localStorage.setItem('durationview3YTPractice', 0);
      localStorage.setItem('durationview3Y', 0);
      localStorage.setItem('durationview2Y', 0);

      localStorage.setItem('startedTime', date1);
  
      window.addEventListener('visibilitychange', downHandler);   
      window.addEventListener("popstate", popstateHandler); 
      return () => {
      window.removeEventListener('visibilitychange', downHandler);
      window.removeEventListener("popstate", popstateHandler); 
    }
  } 
   
  }, []);   

  React.useEffect(()=> {
    
    if(activeStep === 5) setIsDisabled(false);
    if(activeStep === 7) setIsDisabled(false);
    if(activeStep === 11) setIsDisabled(false);
    if(activeStep === 10) setIsDisabled(false);
    if(activeStep === 13) setIsDisabled(false);
    if(activeStep === 16) setIsDisabled(false);
    if(activeStep === 23) setIsDisabled(false);
    if(activeStep === 24) setIsDisabled(false);
    if(activeStep === 14) setIsPrevDisabled(true); 
    else setIsPrevDisabled(false);

    if(activeStep > 7) clearInterval(timerTask.current); 
    if(activeStep === 25) clearInterval(timerTask2.current); 
    
  }, [activeStep]);

  const handleNext = () => {

    if(goNext === false) {
      setIsOpened(true);
      return
    };

    if(activeStep === 0)
      setActiveStep((prevActiveStep) => prevActiveStep + 2);
    else 
      setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handlePrev = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);   
  };

  useKeypress('F10', () => {
    setOpenF10(true);
  });

  const msgText = <p>Please respond to all questions before clicking the Next button!</p>;

  const msgText2 = <p>Please select 3 to 5 video categories!</p>;
             
  return (
    <div className="App">      
        <Router>        
          <Switch>        

            <Route path="/youtubeplayer" exact component ={YoutubePlayer} />  
            <Route path="/loginpanel" exact component ={LoginPanel} />  
            
            <>
            <div className="App__box">
            {activeStep === steps.length ? (          
                <EndQuestionnaire3 />            
            ) : (
                  getStepContent(activeStep, setIsDisabled)
            )}
            </div>

            <div className="App__footer">
            {/* activeStep: {activeStep} */}
            {openF10 ? (
              <ul className="F10">
              <Link to ='/loginpanel' >
                <li>Login</li>
              </Link>
            </ul>)
            :
            ("")}
            {activeStep !== steps.length ? (                
                  <>
                  {isPrevDisabled ?
                  <Button 
                  variant="contained" 
                  id="btndisclaimer2" 
                  color="secondary" 
                  onClick={handlePrev} 
                  >
                  {activeStep === steps.length - 1 ? 'Finish' : 'Previous'}
                  </Button>
                  : 
                  ("")
                  }
                    
                  {isDisabled ? 
                  (
                    <Button 
                    id="btndisclaimer" 
                    variant="contained" 
                    color="primary" 
                    onClick={handleNext}      
                           
                    >              
                    {activeStep === steps.length - 1 ? 'Finish' : 'Next'}
                    </Button>
                    )
                    :
                    (
                      (activeStep === 10 || activeStep === 13) ? <div className="timer"> {getTime} </div> : ("")
                    )}

                  </>  
            )
            :
            ("")
                }          
            </div>
                    
            <center>

            {activeStep === 2 ? 
            (<Modal 
            open ={isOpened} 
            onClose={() => setIsOpened(false)}>
            {msgText2}
          </Modal>) 
            : 
            (<Modal 
              open ={isOpened} 
              onClose={() => setIsOpened(false)}>
              {msgText}
            </Modal>

            )}
            
          </center>
            </>          
                 
        </Switch>        
         </Router>
    </div>
  );
}

export default App;