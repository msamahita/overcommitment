import React from 'react';
import './Loginpanel.css';
import { useHistory } from "react-router-dom";
import { withStyles, makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import VpnKeyIcon from '@material-ui/icons/VpnKey';
import Link from '@material-ui/core/Link';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';

import {firebaseApp} from './firebase';
import CircularProgress from '@material-ui/core/CircularProgress';
import CloudDownloadIcon from '@material-ui/icons/CloudDownload';

import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';

import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';

import Moment from 'moment';

function LoginPanel() {
      
      const useStyles = makeStyles((theme) => ({
        root: {
          '& > *': {
            margin: theme.spacing(1),
            
          },
        },
        table: {
          minWidth: 600,
          position: '-webkit-sticky',
            position: 'sticky',
        },
      }));

      const refData = firebaseApp.firestore().collection('transcriptions');

      const classes = useStyles();

      const originalData = React.useState({email: process.env.REACT_APP_EMAIL, password: process.env.REACT_APP_PASSWORD});

      const [email, setEmail] = React.useState('');
      const [password, setPassword] = React.useState('');
      const [isLoggedin, setIsLoggedin] = React.useState(false);
      const [isLoading, setIsLoading] = React.useState(true);
      const [recordsData, setRecordsData] = React.useState([]);

      const handleEmail =(e) => {
        setEmail(e.target.value);
      }

      const handlepassword =(e) => {
        setPassword(e.target.value);
      }

      const login = (event) =>{
        if(email !== '' && password !== ''){
            originalData.filter((account) => {
                if(account.email === email && account.password === password){
                  //sessionStorage.setItem('IsLoggedin', true);  
                    sessionSet('IsLoggedin', true, 10);     
                    setIsLoggedin(true);
                    alert('Account is accepted!');
                }

                return true;
            });

            setEmail('');
            setPassword('');
            
        }else {
            alert('Please add your correct account!');
        }
      }

      let history = useHistory();

      const popstateHandler = (e) => {
        this.props.history.go(1);
      }

      // get from session (if the value expired it is destroyed)
      function sessionGet(key) {
        let stringValue = window.sessionStorage.getItem(key)
          if (stringValue !== null) {
            let value = JSON.parse(stringValue)
              let expirationDate = new Date(value.expirationDate)
              if (expirationDate > new Date()) {
                return value.value
              } else {
                window.sessionStorage.removeItem(key)
              }
          }
          return null
      }

      function sessionSet(key, value, expirationInMin = 10) {
        let expirationDate = new Date(new Date().getTime() + (60000 * expirationInMin))
          let newValue = {
          value: value,
          expirationDate: expirationDate.toISOString()
        }
        window.sessionStorage.setItem(key, JSON.stringify(newValue))
      }

      React.useEffect(() => {
        if(sessionGet('IsLoggedin'))
          setIsLoggedin(sessionGet('IsLoggedin'));
        else 
          setIsLoggedin(false);

        window.addEventListener("popstate", popstateHandler); 
        return () => {
        window.removeEventListener("popstate", popstateHandler);         
       }
       
      }, []);   

      React.useEffect(() => {

        const unsubscribe  = 
          refData.onSnapshot(snapshot => {
            const newArray = [];

              snapshot.forEach((childSnapshot) => {
                  newArray.push({
                    AcceptParticpation: childSnapshot.data().AcceptParticpation,
                    ProlificID:childSnapshot.data().ProlificID,
                    Categories:childSnapshot.data().Categories,
                    TranscribedCount1:childSnapshot.data().TranscribedCount,
                    TranscribedCount2:childSnapshot.data().TranscribedCount2,
                    TranscribedCount3:childSnapshot.data().TranscribedCount3,
                    PaymentStage:childSnapshot.data().Com,
                    CorrectedAnswers1:childSnapshot.data().CorrectedAnswers1,
                    Tasks1:childSnapshot.data().Tasks1,
                    ExpectedCorrectSubmissions1:childSnapshot.data().ExpectedCorrectSubmissions1,
                    PracticeRoundPrice:childSnapshot.data().PracticeRoundPrice,
                    CoinToss1:childSnapshot.data().CoinToss1,
                    RandomGeneratedNumber1:childSnapshot.data().RandomGeneratedNumber1,
                    PreferredYoutubeThumbnails:childSnapshot.data().PreferredYoutubeThumbnails,
                    ActualRoundPrice:childSnapshot.data().ActualRoundPrice,
                    ExpectedCorrectSubmissions2:childSnapshot.data().ExpectedCorrectSubmissions2,
                    LikelyClickOnThumbnails:childSnapshot.data().LikelyClickOnThumbnails,
                    DoClickExpectedCorrectSubmissions3:childSnapshot.data().DoClickExpectedCorrectSubmissions3,
                    DoNotClickExpectedCorrectSubmissions3:childSnapshot.data().DoNotClickExpectedCorrectSubmissions3,
                    TemptedClick:childSnapshot.data().TemptedClick,
                    RevisedRoundPrice:childSnapshot.data().RevisedRoundPrice,
                    CoinToss2:childSnapshot.data().CoinToss2,
                    RandomGeneratedNumber2:childSnapshot.data().RandomGeneratedNumber2,
                    CorrectedAnswers2:childSnapshot.data().CorrectedAnswers2,
                    Tasks2:childSnapshot.data().Tasks2,                    
                    DurationView:childSnapshot.data().DurationView,
                    DurationView2:childSnapshot.data().DurationView2,
                    LeftTimesMainTab:childSnapshot.data().LeftTimesMainTab,
                    LeftTimesMainTab2:childSnapshot.data().LeftTimesMainTab2,
                    Age:childSnapshot.data().Age,
                    Gender:childSnapshot.data().Gender,
                    SpendTimeOnYoutube:childSnapshot.data().SpendTimeOnYoutube,
                    Option1:childSnapshot.data().Option1,
                    Option2:childSnapshot.data().Option2,
                    Statement1:childSnapshot.data().Statement1,
                    Statement2:childSnapshot.data().Statement2,
                    Statement3:childSnapshot.data().Statement3,
                    Statement4:childSnapshot.data().Statement4,
                    Statement5:childSnapshot.data().Statement5,
                    Statement6:childSnapshot.data().Statement6,
                    Statement7:childSnapshot.data().Statement7,
                    Statement8:childSnapshot.data().Statement8,
                    Statement9:childSnapshot.data().Statement9,
                    Statement10:childSnapshot.data().Statement10,
                    Statement11:childSnapshot.data().Statement11,
                    Statement12:childSnapshot.data().Statement12,
                    Statement13:childSnapshot.data().Statement13,
                    Earnings:childSnapshot.data().Earnings,
                    CostOfRemoving:childSnapshot.data().CostOfRemoving,
                    TotalBonus:childSnapshot.data().TotalBonus,
                    MyExperienceComment:childSnapshot.data().MyExperienceComment,
                    startedTime:new Date(childSnapshot.data().startedTime),
                    endedTime:childSnapshot.data().endedTime,
                    startedTask1:childSnapshot.data().startedTask1,
                    sessionTimeTask1:childSnapshot.data().sessionTimeTask1,
                    startedTask2:childSnapshot.data().startedTask2,
                    sessionTimeTask2:childSnapshot.data().sessionTimeTask2,
                    sessionTime:childSnapshot.data().sessionTime,

                    durationview2YT: childSnapshot.data().durationview2YT,
                    durationview3YT: childSnapshot.data().durationview3YT,
                    durationview2YTPractice: childSnapshot.data().durationview2YTPractice,
                    durationview3YTPractice: childSnapshot.data().durationview3YTPractice,

                    ClickedThumbnailsTab:childSnapshot.data().ClickedThumbnailsTab,
                    ClickedThumbnailsTabPopUp:childSnapshot.data().ClickedThumbnailsTabPopUp,
                    ClickedThumbnailsTabPractice:childSnapshot.data().ClickedThumbnailsTabPractice,
                    ClickedThumbnailsTabPopUpPractice:childSnapshot.data().ClickedThumbnailsTabPopUpPractice,
                    durationPopupShownTask1: childSnapshot.data().durationPopupShownTask1,
                    durationPopupShown: childSnapshot.data().durationPopupShown
                  });
              });                          
              
              const sortedActivities = newArray.sort((a, b) => b.startedTime - a.startedTime)
              setRecordsData(sortedActivities);

             setIsLoading(false);

          }, function (errorObject) {
            console.log("read failed: " + errorObject.code);          
            });   

        return () => unsubscribe();

      }, []);

      const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
      const EXCEL_EXTENSION = '.xlsx';

      const exportCSV = (dataItems, fileName) => {
        const ws = XLSX.utils.json_to_sheet(dataItems);

        const wb = { Sheets: { 'data': ws }, SheetNames: ['data'] };

        const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });

        const data = new Blob([excelBuffer], {type: EXCEL_TYPE});

        FileSaver.saveAs(data, fileName + EXCEL_EXTENSION);
      }  
      const characters ='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

      function generateString(length) {
        let result = ' ';
        const charactersLength = characters.length;
        for ( let i = 0; i < length; i++ ) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
    
        return result;
        }

        const StyledTableCell = withStyles((theme) => ({
          head: {
            backgroundColor: theme.palette.common.black,
            color: theme.palette.common.white,
          },
          body: {
            fontSize: 12,
          },
        }))(TableCell);

        const StyledTableRow = withStyles((theme) => ({
          root: {
            '&:nth-of-type(odd)': {
              backgroundColor: theme.palette.action.hover,
            },
            backgroundColor: '#3755b98b',
          },
        }))(TableRow);
                
    return (
        <div className="half-width-app">
        
              {!isLoggedin ? 
              (
                  <>
              <div className='half-width'>
              <h4>Login Panel</h4>
              <br/>
              <form action="">
                <div className='form-group'>
                  <input type="text" className='form-control' placeholder='Email' value= {email} onChange ={handleEmail}/>
                </div>
                <div className='form-group'>
                  <input type="password" className='form-control' placeholder='Password' value = {password} onChange ={handlepassword}/>
                </div>
                <div className="form-btn">
                <div className={classes.root}>
                <Button
              variant="contained"
              color="primary"
              onClick = {(event) => login()}
              className={classes.button}
              endIcon={<VpnKeyIcon></VpnKeyIcon>}
              >
              Login
              </Button>

                  <Link
              
              component="button"
              color="info"
              variant="body1"
              onClick={() => {
                
                history.push('/');        

              }}
              >
              Back Home
              </Link>

                </div>
                </div>
              </form>
              </div>
              </>
              ) 
              :
              (   
                   <>
              <div className="content">
                
                <div className="header">
                  
                  <div className="header__title"><h3>Admin Panel</h3>
                  </div>
                 
                  <div className="header__icon">
                    <div className="header__download">
                      <CloudDownloadIcon />
                      <Link
                      component="button"
                      variant="body2"
                      onClick={() => {
                        exportCSV(recordsData, 'Transcription_' + generateString(6))
                      }}
                      >
                        Download CSV
                      </Link>
                    </div>

                    <div className="header__download">
                      <ExitToAppIcon />
                      <Link
                      component="button"
                      variant="body2"
                      onClick={() => {
                      sessionStorage.removeItem('IsLoggedin');
                      setIsLoggedin(false);
                      }}
                      >
                      <span>Logout</span>
                      </Link>
                    </div>

                  </div>

                </div>
                
                <div className="content__table">
                
                  {
                  
                  isLoading ? (
                  <center>
                    <CircularProgress />
                    </center>)
                  :
                  (
                  <center>

                  {recordsData && recordsData.length > 0 ?
                  (                 
                    <TableContainer component={Paper}>
                                         
                    <Table className={classes.table} size="small" aria-label="a dense table">
                      <TableHead stickyHeader >
                        <TableRow>

                        <StyledTableCell align="center">StartedTime</StyledTableCell>
                        <StyledTableCell align="center">AcceptParticpation</StyledTableCell>
                        <StyledTableCell align="center">ProlificID</StyledTableCell>
                        <StyledTableCell align="center">Categories</StyledTableCell>
                        <StyledTableCell align="center">TranscribedCount1</StyledTableCell>
                        <StyledTableCell align="center">TranscribedCount2</StyledTableCell>
                        <StyledTableCell align="center">TranscribedCount3</StyledTableCell>
                        <StyledTableCell align="center">PaymentStage</StyledTableCell>
                        <StyledTableCell align="center">CorrectedAnswers1</StyledTableCell>
                        <StyledTableCell align="center">Tasks1</StyledTableCell>
                        <StyledTableCell align="center">ExpectedCorrectSubmissions1</StyledTableCell>
                        <StyledTableCell align="center">PracticeRoundPrice</StyledTableCell>
                        <StyledTableCell align="center">CoinToss1</StyledTableCell>
                        <StyledTableCell align="center">RandomGeneratedNumber1</StyledTableCell>
                        <StyledTableCell align="center">PreferredYoutubetdumbnails</StyledTableCell>
                        <StyledTableCell align="center">ActualRoundPrice</StyledTableCell>
                        <StyledTableCell align="center">ExpectedCorrectSubmissions2</StyledTableCell>
                        <StyledTableCell align="center">LikelyClickOnThumbnails</StyledTableCell>
                        <StyledTableCell align="center">DoClickExpectedCorrectSubmissions3</StyledTableCell>
                        <StyledTableCell align="center">DoNotClickExpectedCorrectSubmissions3</StyledTableCell>
                        <StyledTableCell align="center">TemptedClick</StyledTableCell>
                        <StyledTableCell align="center">RevisedRoundPrice</StyledTableCell>
                        <StyledTableCell align="center">CoinToss2</StyledTableCell>
                        <StyledTableCell align="center">RandomGeneratedNumber2</StyledTableCell>
                        <StyledTableCell align="center">CorrectedAnswers2</StyledTableCell>
                        <StyledTableCell align="center">Tasks2</StyledTableCell>                       
                        <StyledTableCell align="center">DurationView (sec)</StyledTableCell>
                        <StyledTableCell align="center">DurationView2 (sec)</StyledTableCell>
                        <StyledTableCell align="center">LeftTimesMainTab</StyledTableCell>
                        <StyledTableCell align="center">LeftTimesMainTab2</StyledTableCell>
                        <StyledTableCell align="center">Age</StyledTableCell>
                        <StyledTableCell align="center">Gender</StyledTableCell>
                        <StyledTableCell align="center">SpendTimeOnYoutube</StyledTableCell>
                        <StyledTableCell align="center">Option1</StyledTableCell>
                        <StyledTableCell align="center">Option2</StyledTableCell>
                        <StyledTableCell align="center">Statement1</StyledTableCell>
                        <StyledTableCell align="center">Statement2</StyledTableCell>
                        <StyledTableCell align="center">Statement3</StyledTableCell>
                        <StyledTableCell align="center">Statement4</StyledTableCell>
                        <StyledTableCell align="center">Statement5</StyledTableCell>
                        <StyledTableCell align="center">Statement6</StyledTableCell>
                        <StyledTableCell align="center">Statement7</StyledTableCell>
                        <StyledTableCell align="center">Statement8</StyledTableCell>
                        <StyledTableCell align="center">Statement9</StyledTableCell>
                        <StyledTableCell align="center">Statement10</StyledTableCell>
                        <StyledTableCell align="center">Statement11</StyledTableCell>
                        <StyledTableCell align="center">Statement12</StyledTableCell>
                        <StyledTableCell align="center">Statement13</StyledTableCell>
                        <StyledTableCell align="center">Earnings</StyledTableCell>
                        <StyledTableCell align="center">CostOfRemoving</StyledTableCell>
                        <StyledTableCell align="center">TotalBonus</StyledTableCell>    
                        <StyledTableCell align="center">MyExperienceComment</StyledTableCell>                     
                        <StyledTableCell align="center">EndedTime</StyledTableCell>
                        <StyledTableCell align="center">StartedTask1</StyledTableCell>
                        <StyledTableCell align="center">SessionTimeTask1 (sec)</StyledTableCell>
                        <StyledTableCell align="center">StartedTask2</StyledTableCell>
                        <StyledTableCell align="center">SessionTimeTask2 (sec)</StyledTableCell>
                        <StyledTableCell align="center">SessionTime (sec)</StyledTableCell>                         

                        <StyledTableCell align="center">durationview2YTPractice (sec)</StyledTableCell>      
                        <StyledTableCell align="center">durationview3YTPractice (sec)</StyledTableCell>      

                        <StyledTableCell align="center">durationview2YT (sec)</StyledTableCell>    
                        <StyledTableCell align="center">durationview3YT (sec)</StyledTableCell>         

                        <StyledTableCell align="center">ClickedThumbnailsTab</StyledTableCell>      
                        <StyledTableCell align="center">ClickedThumbnailsTabPopUp</StyledTableCell>   

                        <StyledTableCell align="center">ClickedThumbnailsTabPractice</StyledTableCell>      
                        <StyledTableCell align="center">ClickedThumbnailsTabPopUpPractice</StyledTableCell>         

                        <StyledTableCell align="center">durationPopupShownTask1 (sec)</StyledTableCell>   

                        <StyledTableCell align="center">durationPopupShown (sec)</StyledTableCell>                     
                        
                        </TableRow>                     
                      </TableHead>
                      
                      <TableBody>
                        {recordsData && recordsData.map((item) => (
                          <StyledTableRow key={item.ProlificID}>

                              <StyledTableCell align="left"> {Moment(item.startedTime).format('DD-MM-YYYY hh:mm:ss')} </StyledTableCell>
                              <StyledTableCell align="left"> {item.AcceptParticpation} </StyledTableCell>
                              <StyledTableCell align="left" component="th" scope="row"> {item.ProlificID} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Categories} </StyledTableCell>
                              <StyledTableCell align="left"> {item.TranscribedCount1} </StyledTableCell>
                              <StyledTableCell align="left"> {item.TranscribedCount2} </StyledTableCell>
                              <StyledTableCell align="left"> {item.TranscribedCount3} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Com} </StyledTableCell>
                              <StyledTableCell align="left"> {item.CorrectedAnswers1} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Tasks1} </StyledTableCell>
                              <StyledTableCell align="left"> {item.ExpectedCorrectSubmissions1} </StyledTableCell>
                              <StyledTableCell align="left"> {item.PracticeRoundPrice} </StyledTableCell>
                              <StyledTableCell align="left"> {item.CoinToss1} </StyledTableCell>
                              <StyledTableCell align="left"> {item.RandomGeneratedNumber1} </StyledTableCell>
                              <StyledTableCell align="left"> {item.PreferredYoutubeThumbnails} </StyledTableCell>
                              <StyledTableCell align="left"> {item.ActualRoundPrice} </StyledTableCell>
                              <StyledTableCell align="left"> {item.ExpectedCorrectSubmissions2} </StyledTableCell>
                              <StyledTableCell align="left"> {item.LikelyClickOnThumbnails} </StyledTableCell>
                              <StyledTableCell align="left"> {item.DoClickExpectedCorrectSubmissions3} </StyledTableCell>
                              <StyledTableCell align="left"> {item.DoNotClickExpectedCorrectSubmissions3} </StyledTableCell>
                              <StyledTableCell align="left"> {item.TemptedClick} </StyledTableCell>
                              <StyledTableCell align="left"> {item.RevisedRoundPrice} </StyledTableCell>
                              <StyledTableCell align="left"> {item.CoinToss2} </StyledTableCell>
                              <StyledTableCell align="left"> {item.RandomGeneratedNumber2} </StyledTableCell>
                              <StyledTableCell align="left"> {item.CorrectedAnswers2} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Tasks2} </StyledTableCell>                              
                              <StyledTableCell align="left"> {item.DurationView} </StyledTableCell>
                              <StyledTableCell align="left"> {item.DurationView2} </StyledTableCell>
                              <StyledTableCell align="left"> {item.LeftTimesMainTab} </StyledTableCell>
                              <StyledTableCell align="left"> {item.LeftTimesMainTab2} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Age} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Gender} </StyledTableCell>
                              <StyledTableCell align="left"> {item.SpendTimeOnYoutube} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Option1} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Option2} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Statement1} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Statement2} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Statement3} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Statement4} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Statement5} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Statement6} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Statement7} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Statement8} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Statement9} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Statement10} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Statement11} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Statement12} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Statement13} </StyledTableCell>
                              <StyledTableCell align="left"> {item.Earnings} </StyledTableCell>
                              <StyledTableCell align="left"> {item.CostOfRemoving} </StyledTableCell>
                              <StyledTableCell align="left"> {item.TotalBonus} </StyledTableCell> 
                              <StyledTableCell align="left"> {item.MyExperienceComment} </StyledTableCell>  
                              <StyledTableCell align="left"> {Moment(item.endedTime).format('DD-MM-YYYY hh:mm:ss')} </StyledTableCell>
                              <StyledTableCell align="left"> {Moment(item.startedTask1).format('DD-MM-YYYY hh:mm:ss')} </StyledTableCell>
                              <StyledTableCell align="left"> {item.sessionTimeTask1} </StyledTableCell>
                              <StyledTableCell align="left"> {Moment(item.startedTask2).format('DD-MM-YYYY hh:mm:ss')} </StyledTableCell>
                              <StyledTableCell align="left"> {item.sessionTimeTask2} </StyledTableCell>
                              <StyledTableCell align="left"> {item.sessionTime} </StyledTableCell>
                              
                              <StyledTableCell align="left"> {item.durationview2YTPractice} </StyledTableCell>
                              <StyledTableCell align="left"> {item.durationview3YTPractice} </StyledTableCell>

                              <StyledTableCell align="left"> {item.durationview2YT} </StyledTableCell>
                              <StyledTableCell align="left"> {item.durationview3YT} </StyledTableCell>

                              <StyledTableCell align="left"> {item.ClickedThumbnailsTab} </StyledTableCell>
                              <StyledTableCell align="left"> {item.ClickedThumbnailsTabPopUp} </StyledTableCell>

                              <StyledTableCell align="left"> {item.ClickedThumbnailsTabPractice} </StyledTableCell>
                              <StyledTableCell align="left"> {item.ClickedThumbnailsTabPopUpPractice} </StyledTableCell>

                              <StyledTableCell align="left"> {item.durationPopupShownTask1} </StyledTableCell>
                              
                              <StyledTableCell align="left"> {item.durationPopupShown} </StyledTableCell>

                          </StyledTableRow>
                        ))}
                      </TableBody>

                    </Table> 

                    </TableContainer>   

                  )
                  :
                  ("")
                  }     
                               
                  </center>
                   )                  
                   }
                </div>                
                
                <b>{ recordsData.length} records found</b>
              
              </div>
            </>
              )
              }

        </div>    
   )
}
export default React.memo(LoginPanel);