import React from 'react';
import ReactDom from 'react-dom';
import { motion, AnimatePresence } from 'framer-motion'
import { GoogleLogin } from 'react-google-login';
import './Login.css';
import Cookies from 'js-cookie';

import api from './api';

function Login({ open, setIsLoggedIn }) {

    const MODAL_STYLE = {
        position: 'fixed',
        top: '25%',
        left: '25%',
        transform: 'translate (-50%, -50%)',
        transition: 'all 350ms ease-in',
        backgroundColor: '#FFF',
        padding: '20px',
        zIndex: 1000,
        width: '500px',
        height: '300px'
    }

    const OVERLAY_STYLE = {
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0,0,0,.7)',
        zIndex: 1000
    }

    const BTN_STYLE = {
        position: 'fixed',
        right: '40px'
    }

    if (!open) return null

    const onSuccess = async (res) => {
        // setIsLoggedIn(true)
        // Cookies.set("logged", true)
        console.log(res.tokenObj.access_token);
        
        const response = await api.get('videos', {
            params: {
                part : 'snippet',
                chart: 'mostPopular',
                // regionCode: 'TN',
                maxResults : 10,
                key: 'AIzaSyA8_FO8to3fBUn6nkuznnv8upkGC3xl0dA'
            },
            headers: {
                Authorization: res.tokenObj.access_token,
                Accept: 'application/json'
            }
        });

        console.log(response.data.items);
    }

    const onFailure = (err) => {
        console.log(err);
    }
    return ReactDom.createPortal(

        <div><div style={OVERLAY_STYLE}></div>
            <motion.div initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3, type: 'tween' }}
            >
                <div style={MODAL_STYLE}>
                    <div className="modal">
                        <h2>Authentification</h2>
                        <div className="modal_header">
                        </div>
                        <div className="modal_button">
                            <GoogleLogin
                                clientId="662238631002-sbdr2p2rilo8jgfl1ek1a7ssa9mucmsl.apps.googleusercontent.com"
                                buttonText="Login With Google"
                                onSuccess ={onSuccess}
                                onFailure = {onFailure}
                                cookiePolicy={"single_host_origin"}
                                isSignedIn={true}
                                scope = 'https://www.googleapis.com/auth/youtube.readonly'
                            />
                        </div>

                    </div>
                </div>
            </motion.div>
        </div>,
        document.getElementById('portal')
    )
}

export default Login
