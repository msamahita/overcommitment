import React from 'react';
import ReactDom from 'react-dom';
import Button from '@material-ui/core/Button';
import './Modal.css';

function Modal({ open, children, onClose}) {

    
    if(!open) return null

    return ReactDom.createPortal(
        <>
        <div className="OVERLAY_STYLE" >            
        </div>
            <div className = "MODAL_STYLE">        
            <Button 
            className="BTN_STYLE" 
            color="secondary" 
            onClick={onClose}>
                Close
            </Button>                    
             <><b>{children}</b></>
            </div>
        </>,
        document.getElementById('portal')
    )
}

export default Modal
