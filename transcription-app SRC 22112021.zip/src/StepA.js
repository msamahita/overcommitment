import React , {useEffect} from 'react';
import './StepA.css';

import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';

import Step1 from './Steps/Step1';
import Step2 from './Steps/Step2';
import Step3 from './Steps/Step3';
import Step4 from './Steps/Step4';
import Step5 from './Steps/Step5';
import Step6 from './Steps/Step6';
import Step7 from './Steps/Step7';
import Step8 from './Steps/Step8';
import Step9 from './Steps/Step9';
import Step92 from './Steps/Step92';
import Step93 from './Steps/Step93';
import Step10 from './Steps/Step10';
import Step11 from './Steps/Step11';
import Step12 from './Steps/Step12';
import Step13 from './Steps/Step13';
import Step14 from './Steps/Step14';
import Step15 from './Steps/Step15';
import Step16 from './Steps/Step16';
import Step17 from './Steps/Step17';
import Step20 from './Steps/Step20';
import Stage1 from './Steps/Stage1';
import Stage2 from './Steps/Stage2';
import EndQuestionnaire from './Steps/EndQuestionnaire';
import EndQuestionnaire2 from './Steps/EndQuestionnaire2';
import EndQuestionnaire3 from './Steps/EndQuestionnaire3';

import {UserContext} from './App';

const useStyles = makeStyles((theme) => ({
    root: {
      width: '100%'
    },
    backButton: {
      marginRight: theme.spacing(1),
    },
    instructions: {
      marginTop: theme.spacing(1),
      marginBottom: theme.spacing(1),
    },
  }));
  

function StepA() {

  function getSteps() {
    return ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''];
  }
  
  function getStepContent(stepIndex, setIsDisabled) {
    switch (stepIndex) {
        case 0:
        return <Step1 setIsDisabled={setIsDisabled}/>;
        case 1:
        return <Step2 setIsDisabled={setIsDisabled}/>;
        case 2:
        return <Step3 />;
        case 3:
        return <Step4 />;
        case 4:
        return <Step5 setIsDisabled={setIsDisabled} handleNext= {handleNext}/>;
        case 5:
        return <Step6 />;
        case 6:
        return <Stage1 setIsDisabled={setIsDisabled} handleNext = {handleNext}/>;
        case 7:
        return <Step7 />;
        case 8:
        return <Step8 setIsDisabled={setIsDisabled}/>;
        case 9:
        return <Step9 />;
        case 10:
        return <Step92 />;
        case 11:
        return <Step93 />;

        case 12:
        return <Step10 setIsDisabled={setIsDisabled}/>;
        case 13:
        return <Step11 setIsDisabled={setIsDisabled}/>;
        case 14:
        return <Step12 setIsDisabled={setIsDisabled}/>;
        case 15:
        return <Step13 setIsDisabled={setIsDisabled}/>;
        case 16:
        return <Step14 setIsDisabled={setIsDisabled}/>;
        case 17:
        return <Step20 />;
        case 18:
        return <Step15 setIsDisabled={setIsDisabled}/>;
        case 19:
        return <Step16 setIsDisabled={setIsDisabled}/>;
        case 20:
        return <Step17 setIsDisabled={setIsDisabled}/>;
        case 21:
        return <Stage2 setIsDisabled={setIsDisabled} handleNext= {handleNext} />;
        case 22:
        return <EndQuestionnaire setIsDisabled={setIsDisabled}/>;
        case 23:
        return <EndQuestionnaire2 />;       

      default:
        return '';
    }
  }

  const [userData, setUserData] = React.useContext(UserContext);

  const [count, setCount] = React.useState(0);
  
  const downHandler = () => {
        
   if(document.visibilityState === 'visible') {
    
    document.title = 'Transcription App'
     setCount(prevCount => prevCount + 1) 
     setUserData({... userData, WatchingVideo : false});
   } 
   else 
    document.title = 'Plz, back to complete tasks'
  }
  
  const popstateHandler = (e) => {
    this.props.history.go(1);
  }

  useEffect(() => {
      window.addEventListener('visibilitychange', downHandler);   
      window.addEventListener("popstate", popstateHandler); 
      return () => {
      window.removeEventListener('visibilitychange', downHandler);
      window.removeEventListener("popstate", popstateHandler); 
     }     
     
    }, []);   
    
  const classes = useStyles();
  const [activeStep, setActiveStep] = React.useState(0);
  const [isDisabled, setIsDisabled] = React.useState(false);
  const [isPrevDisabled, setIsPrevDisabled] = React.useState(false);
  const steps = getSteps();

  useEffect(()=> {
    if(activeStep === 1) setIsDisabled(false);
    if(activeStep === 4) setIsDisabled(false);
    if(activeStep === 6) setIsDisabled(false);
    if(activeStep === 8) setIsDisabled(false);
    if(activeStep === 12) setIsDisabled(false);
    if(activeStep === 14) setIsDisabled(false);
    if(activeStep === 15) setIsDisabled(false);
    if(activeStep === 16) setIsDisabled(false);
    if(activeStep === 18) setIsDisabled(false);
    if(activeStep === 19) setIsDisabled(false);
    if(activeStep === 22) setIsDisabled(false);

    if(activeStep === 10 || activeStep === 11) setIsPrevDisabled(true); else setIsPrevDisabled(false);

  }, [activeStep]);

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);   
  };

  const handlePrev = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);   
  };

  return (
    <div>
      <div>
        {activeStep === steps.length ? (
          <div>
            <Typography className={classes.instructions}>
            <EndQuestionnaire3 />
            </Typography>            
          </div>
        ) : (
            <div className="content"> {getStepContent(activeStep, setIsDisabled)}
                {/* <Typography className={classes.instructions}>
                   
                </Typography>                 */}
          </div>
        )}
      </div>
      <div className="bottom">  
      {/* Active Step: {activeStep} */}
      
          {activeStep !== steps.length ? (
             isDisabled ? (
              <>             
              {isPrevDisabled ?
              <Button 
              variant="contained" 
              color="secondary" 
              onClick={handlePrev} 
              >
              {activeStep === steps.length - 1 ? 'Finish' : 'Previous'}
              </Button>
              : ("")
                }
              <Button 
              variant="contained" 
              color="primary" 
              onClick={handleNext} 
              >
              {activeStep === steps.length - 1 ? 'Finish' : 'Next'}
              </Button>
              </>
             )          
             :
             ("")
          )
          : ("")
          }         

      </div>
    </div>
  );
}

export default StepA;