import firebase from 'firebase';
import 'firebase/storage'; // If using Storage

export const firebaseApp = firebase.initializeApp(
    {
        
        apiKey: "AIzaSyC3uMO6y_7BINNr__aDwlSAD8sbDLnPTMk",
        authDomain: "transcription-app-b774c.firebaseapp.com",
        projectId: "transcription-app-b774c",
        storageBucket: "transcription-app-b774c.appspot.com",
        messagingSenderId: "255058185340",
        appId: "1:255058185340:web:f5be973ae9535d6d768df9"
 
        // apiKey: "AIzaSyANwSjZGUvfsYg15Cas2iD9jM_m5xY6knE",
        // authDomain: "transcriptiontask-f46b6.firebaseapp.com",
        // projectId: "transcriptiontask-f46b6",
        // storageBucket: "transcriptiontask-f46b6.appspot.com",
        // messagingSenderId: "880698923704",
        // appId: "1:880698923704:web:28f14a9ed4109e59d9324d"
    }    
);

// const firebaseConfig = {
//     apiKey: process.env.REACT_APP_FIREBASE_API_KEY,
//     authDomain: process.env.REACT_APP_FIREBASE_AUTH_DOMAIN,
//     projectId: process.env.REACT_APP_FIREBASE_PROJECT_ID
// };