import React, { useState, useEffect } from 'react';
import './Header.css';
import Countdown from "react-countdown";
import { GoogleLogout } from 'react-google-login';

import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import IconButton from '@material-ui/core/IconButton';
import AccessAlarmIcon from '@material-ui/icons/AccessAlarm';

import Cookies from 'js-cookie';

function Header({ setIsLoggedIn, completedTasks }) {

    //const [completedTasks, setCompletedTasks] = useState(0);
    
    const logout = () => {
        // setIsLoggedIn(false)
        Cookies.set("logged", false)
    }

    const failed = () => {
        alert('failed')
    }

    const Completionist = () => <span>00:00</span>;

    const completedtask = () => {
       // alert('Survey Transcription Has Completed.\Thank you !');
    }

    return (
        <div className="leftsurvey__header">
                        
            <div className="leftsurvey__leftheader">
                <h2>Tasks completed so far: {completedTasks} of 10</h2>
                <p>This work is mandatory to complete the experiment.</p>
            </div>

            <div className="leftsurvey__rightheader">
                <AccessAlarmIcon />
                <span>
                    <Countdown
                        onComplete={completedtask}
                        autoStart={true}
                        date={Date.now() + 600000}>
                        <Completionist />
                    </Countdown>
                </span>

                <div className="leftsurvey__rightheader2">

                {/* <button type="button" onClick= {logout}>Logout</button> */}

                    <GoogleLogout
                        clientId="662238631002-sbdr2p2rilo8jgfl1ek1a7ssa9mucmsl.apps.googleusercontent.com"
                        buttonText="Logout"
                        onLogoutSuccess={logout}
                        render={renderProps => (
                            <ExitToAppIcon onClick={renderProps.onClick} disabled={renderProps.disabled}>Logout</ExitToAppIcon>
                        )}
                    >
                    </GoogleLogout>


                </div>
            </div>

        </div>
    )
}

export default React.memo(Header);
