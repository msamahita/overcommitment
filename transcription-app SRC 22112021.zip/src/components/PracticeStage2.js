import React, { useState, useEffect } from 'react';
import '../components/PracticeStage1.css';
import Button from '@material-ui/core/Button';

import btnA from '../pics/a2.png';
import btnB from '../pics/b2.png';
import btnC from '../pics/c2.png';
import btnD from '../pics/d2.png';
import btnE from '../pics/e2.png';
import btnF from '../pics/f2.png';
import btnG from '../pics/g2.png';
import btnH from '../pics/h2.png';
import btnI from '../pics/i2.png';
import dot from '../pics/k2.png';
import back from '../pics/back.png';

import _btnA from '../pics/a.png';
import _btnB from '../pics/b.png';
import _btnC from '../pics/c.png';
import _btnD from '../pics/d.png';
import _btnE from '../pics/e.png';
import _btnF from '../pics/f.png';
import _btnG from '../pics/g.png';
import _btnH from '../pics/h.png';
import _btnI from '../pics/i.png';
import _dot from '../pics/k.png';

import data from './Data';
import AccessAlarmIcon from '@material-ui/icons/AccessAlarm';
import api from '../api';
import Cookies from 'js-cookie';

import categories2 from '../Steps/Categories';
import Modal2 from '../Modal2';

function PracticeStage2({setIsDisabled, handleNext}) {
        
    const [videos, setVideos] = useState([]);  
    const [count, setCount] = useState(120);    
    const [answeredPic, setansweredPic] = useState('');
    const [images, setimages] = useState([]);
    const [pic, setPic] = useState();
    const [completedTasks, setCompletedTasks] = useState(0);   
    const [realData, setRealData] = React.useState('');
    const [answeredCharacter, setAnsweredCharacter] = React.useState(0);
    let character = '';
    const [newArray, setNewArray] = React.useState([]);
    let index = 1;
    let tempArr = React.useRef([]);
    const [newAnswer, setNewAnswer] = useState([]);
    let count2 = 0;
    const newWindow = React.useRef(null);
    const timerTask = React.useRef();

    const usedRefreshTime = React.useRef(null);
    const [showBtn, setShowBtn] = React.useState('none');

    useEffect(() => {        
        
        setIsDisabled(false);    
        setNewArray([]);
        localStorage.setItem('TranscribedCount2', 0);
        localStorage.setItem('TranscribedCount3', 0);

        let myArray = (JSON.parse(Cookies.get('Categories')));      
        
        for(let i = 0; i < myArray.length; i++) {
           getVideosAPIByElement(categories2.indexOf(myArray[i]));              
        }      
        generateValue();   
        
        // timerTask.current = setInterval(() => {
        //     let n = Number(localStorage.getItem('durationPopupShown'));
        //     n = n + 1;

        //     localStorage.setItem('durationPopupShown', n);
        // }, 1000);
        
    }, []);

    useEffect(() =>{
               
        const unsub = setInterval(() => {          

        const data = localStorage.getItem('videos');
        
        setVideos([]);
        tempArr.current = JSON.parse(data);
        
        let tempA =[];

        if(tempArr.current && tempArr.current.length >0) {
            
            for(let i = 0; i < 10 ; i++) {
                tempA.push(tempArr.current[i]);
            }           
            
            let newVideosFiltered = [];
            for(let i = 10; i < tempArr.current.length ; i++) {
                newVideosFiltered.push(tempArr.current[i]);
            }
            
            localStorage.setItem('videos', JSON.stringify(newVideosFiltered));

            setVideos(tempA);            
        }
        clearInterval(unsub);  
        startTimerNow2();

        }, 1500);
        return () => clearInterval(unsub);     
    }, []);     

    useEffect(() => {
        if (count <= 0) {       
            if(newWindow.current) newWindow.current.close();      
            setIsDisabled(true);            
            handleNext();  
        }
    }, [count]);
    
    useEffect(() => {
        if(completedTasks === 2) 
        {            
            if(newWindow.current) newWindow.current.close();            
            setIsDisabled(true);
            handleNext(); 
        }        
    }, [completedTasks]);
    
    const checkCorrectedCharacters = (i, data) => {
        setNewAnswer([...newAnswer, data]);  
    }

    const addletter = (event) => {
        if (images.length >= 35 && event.target.id !== 'Back') {
            return;
        }               
        
        switch (event.target.id) {
            case 'A':
                setimages([...images, _btnA]);
                setansweredPic(answeredPic => answeredPic + 'a');
                character = 'a';
                checkCorrectedCharacters(+answeredPic.length, character);
                break

            case 'B':
                setimages([...images, _btnB]);
                setansweredPic(answeredPic => answeredPic + 'b');
                character = 'b';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'C':
                setimages([...images, _btnC]);
                setansweredPic(answeredPic => answeredPic + 'c');
                character = 'c';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'D':
                setimages([...images, _btnD]);
                setansweredPic(answeredPic => answeredPic + 'd');
                character = 'd';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'E':
                setimages([...images, _btnE]);
                setansweredPic(answeredPic => answeredPic + 'e');
                character = 'e';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'F':
                setimages([...images, _btnF]);
                setansweredPic(answeredPic => answeredPic + 'f');
                character = 'f';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'G':
                setimages([...images, _btnG]);
                setansweredPic(answeredPic => answeredPic + 'g');
                character = 'g';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'H':
                setimages([...images, _btnH]);
                setansweredPic(answeredPic => answeredPic + 'h');
                character = 'h';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'I':
                setimages([...images, _btnI]);
                setansweredPic(answeredPic => answeredPic + 'i');
                character = 'i';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'Dot':
                setimages([...images, _dot]);
                setansweredPic(answeredPic => answeredPic + '.');
                character = '.';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'Back':

                if (images.length > 0) {
                    images.pop();
                    setimages([...images]);
                    setansweredPic(answeredPic.slice(0, -1));
                    newAnswer.splice(-1,1);
                    setNewAnswer([...newAnswer]);
                }
                else {
                    setimages([]);
                    setimages([]);
                    setansweredPic('');
                    setAnsweredCharacter(0);
                }
                break

            default:
                break
        }       
    }

    const generateValue = React.useCallback(() => {
        const RandomNumber = Math.floor(Math.random() * 1000) + 1;
        setPic(RandomNumber + '.gif');
        setRealData(data[RandomNumber-1]); 
        setansweredPic('');                                       
    }, []);

    const checkAccuracyResponse = () => {

        count2 =0;
        for(let i =0; i < newAnswer.length; i++){
            if(newAnswer[i] === realData[i]){
                
                count2 = count2 + 1;
            }
        }

        if(completedTasks === 0){
        let oldV2 = 0;
        oldV2 = Number(localStorage.getItem('TranscribedCount2'));
        localStorage.setItem('TranscribedCount2', oldV2 + count2);
        }
        else if(completedTasks === 1){
        let oldV3 = 0;
        oldV3 = Number(localStorage.getItem('TranscribedCount3'));
        localStorage.setItem('TranscribedCount3', oldV3 + count2);
        }

    }
    
    const loadPic = (event) => {
        
        if (images.length < 1) return null;
        shiftVideos();

        setOpen2(true);
        startTimerNow2();

        checkAccuracyResponse();      
      
        setCompletedTasks(prevCompletedTasks => prevCompletedTasks + 1);
        setNewAnswer([]);
        setimages([]);
        setansweredPic([]);
        setAnsweredCharacter(0);
        generateValue();          
    }

    const shiftVideos = () => {
                  
        const data = localStorage.getItem('videos');
        let count = localStorage.getItem('count');        
        
        if(!tempArr.current) return;
        if(Number(count) >= Math.ceil(tempArr.current.length/10) * 10) return;
        
        tempArr.current = JSON.parse(data);        
        let tempA =[];
        
        if(tempArr.current && tempArr.current.length >0) {
            for(let i = Number(count); i < (Number(count) + 10) ; i++) {
                tempA.push(tempArr.current[i]);
            }
            
            setVideos(tempA);
            count = Number(count) + (10);
            localStorage.setItem('count', count);            
        }       
    }  

    const getVideo = (e, videoId) => 
    {  
        e.preventDefault();   
        newWindow.current = window.open("/youtubeplayer?videoId=" + videoId +"&mode=tsk&loader=practice", "_blank");      
        let n = Number(localStorage.getItem('ClickedThumbnailsTabPractice'));
        n= n + 1;
        localStorage.setItem('ClickedThumbnailsTabPractice', n);  
    }

    const getVideosAPIByElement = async (element) => {
        let nextPageToken = '';
        let newResponse =[];
        const response = await api.get('videos', {
        params: {
            part : 'snippet',
            chart: 'mostPopular',
            maxResults : 50,
            regionCode: 'US',
            videoCategoryId: element,
            type:'video',
            order: 'viewCount',
            hl: 'en_US',
            key: process.env.REACT_APP_CLIENT_SECRET
        },
        headers: {
            Accept: 'application/json'
        }            
        });        

        if(response){                
                response.data.items.forEach((item)=> {  
                newResponse.push({
                    Id: Math.random(),
                    VideoId: item.id,
                    Thumbnail: item.snippet.thumbnails.medium.url,
                    Title: item.snippet.title
                });
            });

            if(response.data.nextPageToken !== '')
                {
                    nextPageToken = response.data.nextPageToken;
                   
                    for(let i =1; i <4; i++){
                    
                    const NextResponse = await api.get('videos', {
                        params: {
                            part : 'snippet',
                            chart: 'mostPopular',
                            maxResults : 50,
                            regionCode: 'US',
                            videoCategoryId: element,
                            type:'video',
                            order: 'viewCount',
                            hl: 'en_US',
                            pageToken : nextPageToken,
                            key: process.env.REACT_APP_CLIENT_SECRET
                        },
                        headers: {
                            Accept: 'application/json'
                        }            
                        });
        
                        if(NextResponse){
                            NextResponse.data.items.forEach((item)=> {  
                                newResponse.push({
                                    Id: Math.random(),
                                    VideoId: item.id,
                                    Thumbnail: item.snippet.thumbnails.medium.url,
                                    Title: item.snippet.title
                                });
                            });
                        }
                        
                        if(NextResponse.data.nextPageToken){
                            nextPageToken = NextResponse.data.nextPageToken;                            
                        }
                    }         
                }            
            
                newResponse.forEach((element)=> {               
                newArray.push({
                    Id: element.Id,
                    VideoId: element.VideoId,
                    Thumbnail: element.Thumbnail,
                    Title: element.Title
                });
                index = index + 1;
            });

            let shuffledNewArray = newArray.sort((a, b) => a.Id - b.Id);

            if(shuffledNewArray && shuffledNewArray.length > 0){
                localStorage.setItem('videos', JSON.stringify(shuffledNewArray)); 
            }
        }
    }    
    
    const [isOpen2, setOpen2] = useState(true);

    const onClose2 = () => {     
        clearInterval(timerTask.current);
        setOpen2(false);     
        setShowBtn('none');    
    };  

    const startTimerNow2 = () =>{
        usedRefreshTime.current = setInterval(() => startTimer2(), 2000);  
    }

    const startTimer2 = () => {   
        clearInterval(usedRefreshTime.current);
        setShowBtn('block');
    }

    return (
        <div className="leftsurvey" > 
        
        <div>
            <div className="leftsurvey__header">                           
                <div className="leftsurvey__leftheader">
                    <span>Tasks completed so far: {completedTasks}</span>
                    <span>This work is mandatory to complete the experiment.</span>
                </div>

                <div className="leftsurvey__centerheader">
                <span>Practice task with thumbnails</span>        
                </div>      

                <div className="leftsurvey__rightheader">
                <AccessAlarmIcon />
                </div>                   

            </div>
    
            <div className="leftsurvey__content">
            
            <center>
            
                <div className="leftsurvey__box">                

                <div className="leftsurvey__contentPicture">
                
                <img src={process.env.PUBLIC_URL + `/transcriptionpics/Pic${pic}`} 
                    alt="" className="vertical-center" />
                </div>

                <div className="leftsurvey__contentResponse">
                {/* {character} */}
                {images.map(image => (
                        <img className="picture_info" src={image} alt="Logo"
                        />
                    ))}
                </div>

                <div className="leftsurvey__contentButtons">
                    {completedTasks < 10000 ? ( 
                    <>
                    <img key="A" id="A" onClick={addletter} src={btnA} alt="" />
                    <img key="B" id="B" onClick={addletter} src={btnB} alt="" />
                    <img key="C" id="C" onClick={addletter} src={btnC} alt="" />
                    <img key="D" id="D" onClick={addletter} src={btnD} alt="" />
                    <img key="E" id="E" onClick={addletter} src={btnE} alt="" />
                    <img key="F" id="F" onClick={addletter} src={btnF} alt="" />
                    <img key="G" id="G" onClick={addletter} src={btnG} alt="" />
                    <img key="H" id="H" onClick={addletter} src={btnH} alt="" />
                    <img key="I" id="I" onClick={addletter} src={btnI} alt="" />

                    <img key="Dot" id="Dot" onClick={addletter} src={dot} alt="Dot" />
                    <img key="Back" id="Back" onClick={addletter} src={back} alt="Back" />
                    </>
                    )                    
                    :                    
                    ("")}
                </div>

                <div className="leftsurvey__contentSubmit">
                    {
                        <Button variant="contained" onClick={(e) => loadPic(e)} color="primary">
                        Submit
                        </Button>
                    }                    
                </div>
                
                <div className="leftsurvey__sidebar2">    
                    
                    {  
                        videos.length >0 && videos.map((video, index) => (
                        <>
                            
                            {index < 5 ? (<div className="topShow">
                            <>
                            <img 
                            className="leftsurvey__sidebar_img2" 
                            src={video.Thumbnail} 
                            alt= { video.VideoId }
                            title = {video.Title }
                            key = {video.VideoId} 
                            onClick= {(e) => getVideo(e, video.VideoId)}
                            />
                            <span className="descriptionClass2 limtiCharClass">{video.Title}
                            </span>
                            </>
                            </div>) : ("")}                            

                            {index > 4 ? (<div className="downShow">
                            <>
                            <img 
                            className="leftsurvey__sidebar_img2" 
                            src={video.Thumbnail} 
                            alt= { video.VideoId }
                            title = {video.Title }
                            key = {video.VideoId} 
                            onClick= {(e) => getVideo(e, video.VideoId)}
                            />
                            <span className="descriptionClass2 limtiCharClass">{video.Title}
                            </span>
                            </>
                            </div>) : ("")
                            }

                        </>
                        ))                    
                    }  

                    {/* {
                        <div className="isShowModal">
                                <YouTube 
                                videoId = {"H9154xIoYTA"}
                                opts={opts}
                                onReady={_onReady}
                                onPlay = {_onPlay}
                                onStateChange = {_onStateChange}                                        
                                />
                        </div>
                    } */}
                                
                </div>                      
                
            </div>

            </center>

            </div> 
            
            <div>
                <Modal2 
                    open2={isOpen2} 
                    onClose2= {onClose2}
                    children = {videos} 
                    stage= '1' 
                    newWindow = {newWindow}      
                    showBtn = {showBtn}   
                    >
                </Modal2>
            </div>
            
        </div>

    </div>
    );
}

export default React.memo(PracticeStage2);