import React, {useState } from 'react';
import './RightSideBar.css';
import Thumbnail from './Thumbnail';

function RightSideBar() {
    
    
    return (
        
        <div className="rightsidebar" >

           <div className="rightsidebar__thumbnails">                                
                <Thumbnail photo="https://www.maketecheasier.com/assets/uploads/2018/07/Thumbnail-makers-for-youtube-featured-800x400.jpg.webp" id="LyLa7dU5tp8" />   
            </div>

            <div className="rightsidebar__thumbnails">                                
                <Thumbnail photo="https://www.maketecheasier.com/assets/uploads/2018/07/Thumbnail-makers-for-youtube-featured-800x400.jpg.webp" id="LyLa7dU5tp8" />   
            </div>
                        

        </div>
    )
}

export default React.memo(RightSideBar);