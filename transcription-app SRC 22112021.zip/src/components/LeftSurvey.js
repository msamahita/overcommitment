import React, { useState, useEffect } from 'react';
import './LeftSurvey.css';
import Button from '@material-ui/core/Button';

import btnA from '../pics/a2.png';
import btnB from '../pics/b2.png';
import btnC from '../pics/c2.png';
import btnD from '../pics/d2.png';
import btnE from '../pics/e2.png';
import btnF from '../pics/f2.png';
import btnG from '../pics/g2.png';
import btnH from '../pics/h2.png';
import btnI from '../pics/i2.png';
import dot from '../pics/k2.png';
import back from '../pics/back.png';

import _btnA from '../pics/a.png';
import _btnB from '../pics/b.png';
import _btnC from '../pics/c.png';
import _btnD from '../pics/d.png';
import _btnE from '../pics/e.png';
import _btnF from '../pics/f.png';
import _btnG from '../pics/g.png';
import _btnH from '../pics/h.png';
import _btnI from '../pics/i.png';
import _dot from '../pics/k.png';

import Countdown from "react-countdown";

import AccessAlarmIcon from '@material-ui/icons/AccessAlarm';

function LeftSurvey() {

    useEffect(() => {
        generateValue()        
    }, []);
    
    const [csv, setcsv] = useState([]);

    const Completionist = () => <span>00:00</span>;

    const [answeredPic, setansweredPic] = useState('');

    const [images, setimages] = useState([]);

    const [pic, setPic] = useState();

    const [completedTasks, setCompletedTasks] = useState(0);
    
    const addletter = (event) => {
        if (images.length >= 35 && event.target.id !== 'Back') {
            return;
        }

        switch (event.target.id) {
            case 'A':
                setimages([...images, _btnA]);
                setansweredPic(answeredPic => answeredPic + 'a');
                break

            case 'B':
                setimages([...images, _btnB]);
                setansweredPic(answeredPic => answeredPic + 'b');
                break

            case 'C':
                setimages([...images, _btnC]);
                setansweredPic(answeredPic => answeredPic + 'c');
                break

            case 'D':
                setimages([...images, _btnD]);
                setansweredPic(answeredPic => answeredPic + 'd');
                break

            case 'E':
                setimages([...images, _btnE]);
                setansweredPic(answeredPic => answeredPic + 'e');
                break

            case 'F':
                setimages([...images, _btnF]);
                setansweredPic(answeredPic => answeredPic + 'f');
                break

            case 'G':
                setimages([...images, _btnG]);
                setansweredPic(answeredPic => answeredPic + 'g');
                break

            case 'H':
                setimages([...images, _btnH]);
                setansweredPic(answeredPic => answeredPic + 'h');
                break

            case 'I':
                setimages([...images, _btnI]);
                setansweredPic(answeredPic => answeredPic + 'i');
                break

            case 'Dot':
                setimages([...images, _dot]);
                setansweredPic(answeredPic => answeredPic + '.');
                break

            case 'Back':

                if (images.length > 0) {
                    images.pop();
                    answeredPic.slice(0, -1);
                    setimages([...images]);
                    setansweredPic(answeredPic);
                }
                else {
                    setimages([]);
                    setansweredPic('');
                }
                break

            default:
                break
        }
    }

    const generateValue = () => {
        const RandomNumber = Math.floor(Math.random() * 1000) + 1;
        setPic(RandomNumber + '.gif')
    }

    const loadPic = () => {

        if (images.length < 5) return null

        if (completedTasks == 10) { completedtask(); return null;}

        setCompletedTasks(completedTasks => completedTasks + 1)

        setimages([])

        const RandomNumber = Math.floor(Math.random() * 1000) + 1
        setPic(RandomNumber + '.gif')

        // parentCallback(completedTasks)

        setcsv([...csv, {
            participantId: "1",
            pictureId: pic,
            answeredPic: answeredPic,
            completedTask: completedTasks,
            openedVideo: "",
            durationView: ""
        }]);

        console.log(csv);
    }

    const completedtask = () => {
        setimages([]);
        alert('Survey Transcription Has Completed.\Thank you !');
    }

    return (
        <div className="leftsurvey" >

            <div className="leftsurvey__header">
               <center>Practice Task</center>
               
                <div className="leftsurvey__leftheader">
                    <h2>Tasks completed so far: {completedTasks}</h2>
                    <p>This work is mandatory to complete the experiment.</p>
                </div>

                <div className="leftsurvey__rightheader">
                    <AccessAlarmIcon />
                    <span>
                        <Countdown
                            onComplete={completedtask}
                            autoStart={true}
                            date={Date.now() + 600000}>
                            <Completionist />
                        </Countdown>
                    </span>                    
                </div>

            </div>

            <div className="leftsurvey__content">

                <div className="leftsurvey__contentPicture">
                    <img src={process.env.PUBLIC_URL + `/transcriptionpics/Pic${pic}`} 
                    alt="" />
                </div>

                <div className="leftsurvey__contentResponse">
                    {images.map(image => (
                        <img className="picture_info" src={image} alt="Logo" />
                    ))}
                </div>

                <div className="leftsurvey__contentButtons">
                    <img key="A" id="A" onClick={addletter} src={btnA} alt="" />
                    <img key="B" id="B" onClick={addletter} src={btnB} alt="" />
                    <img key="C" id="C" onClick={addletter} src={btnC} alt="" />
                    <img key="D" id="D" onClick={addletter} src={btnD} alt="" />
                    <img key="E" id="E" onClick={addletter} src={btnE} alt="" />
                    <img key="F" id="F" onClick={addletter} src={btnF} alt="" />
                    <img key="G" id="G" onClick={addletter} src={btnG} alt="" />
                    <img key="H" id="H" onClick={addletter} src={btnH} alt="" />
                    <img key="I" id="I" onClick={addletter} src={btnI} alt="" />

                    <img key="Dot" id="Dot" onClick={addletter} src={dot} alt="Dot" />
                    <img key="Back" id="Back" onClick={addletter} src={back} alt="Back" />

                </div>

                <div className="leftsurvey__contentSubmit">
                    <Button variant="contained" onClick={loadPic} color="primary">
                        Submit
                    </Button>
                </div>

            </div>

        </div>
    )
}

export default LeftSurvey