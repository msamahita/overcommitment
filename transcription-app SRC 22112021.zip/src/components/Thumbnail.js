import React, { useState, useEffect } from 'react';
import './Thumbnail.css';
import Modal from '../Modal';

export function getBrowserVisibilityProp() {
    if (typeof document.hidden !== "undefined") {
      // Opera 12.10 and Firefox 18 and later support
      return "visibilitychange"
    } else if (typeof document.msHidden !== "undefined") {
      return "msvisibilitychange"
    } else if (typeof document.webkitHidden !== "undefined") {
      return "webkitvisibilitychange"
    }
  }
  export function getBrowserDocumentHiddenProp() {
    if (typeof document.hidden !== "undefined") {
      return "hidden"
    } else if (typeof document.msHidden !== "undefined") {
      return "msHidden"
    } else if (typeof document.webkitHidden !== "undefined") {
      return "webkitHidden"
    }
  }
  export function getIsDocumentHidden() {
    return !document[getBrowserDocumentHiddenProp()]
  }
  
  export function usePageVisibility() {
    const [isVisible, setIsVisible] = React.useState(getIsDocumentHidden())
    const onVisibilityChange = () => setIsVisible(getIsDocumentHidden())
    React.useEffect(() => {
      const visibilityChange = getBrowserVisibilityProp()
      document.addEventListener(visibilityChange, onVisibilityChange, false)
      return () => {
        document.removeEventListener(visibilityChange, onVisibilityChange)
      }
    })
    return isVisible
  }

function Thumbnail({ photo, id }) {
    

    const isVisible = usePageVisibility();
    
    const [isOpen, setOpen] = useState(false)
    const [getid, setId] = useState()

    const clickOnIt = (e) => {
        setOpen(true);
        setId(e.target.id);
    }

    const [openedTab, setOpenedTab] = useState(null);
    const navigateToExternalUrl = (url) => {
        setOpenedTab (window.open(url, "_blank"));
        setCount(count + 1);
    }

    const closeTab = () => {
        window.opener = null;
        window.open('', '_self');
        window.close();
    }

    const handleBlur = () => {
        console.log('Blur');
      }
    
      const handleFocus = () => {
        console.log('Focus');
      }

    const [count, setCount] = useState(0);

    useEffect(() => {
        const timer = setTimeout(() => {
            closeTab();
        }, 5000);
        return () => clearTimeout(timer);
      }, []);

    return (
        <div        
        
        className="thumbnail">
            <img onClick ={navigateToExternalUrl} id={id} src="" alt={id} />    {isVisible ? document.title = 'Yes' : document.title = 'No'}
            <>
            <Modal open ={isOpen} onClose={() => setOpen(false)}>
            {getid}
            </Modal>
            </>         
        </div>
    )
}

export default Thumbnail
