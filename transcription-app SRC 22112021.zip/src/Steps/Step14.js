import React from 'react';
import './Step12.css';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';

function Step14({setGoNext, setIsDisabled}) {

      const [inputValue, setInputValue] = React.useState();
      
      React.useEffect(()=>{
        setGoNext(false);
      },[]);

      const handleChangeValue = (event) => {
      if(event.target.value >= 0){
        setInputValue(event.target.value.replace(/[^0-9]/g, ''));
        localStorage.setItem('ExpectedCorrectSubmissions2', event.target.value);
        setGoNext(true);
      }else {
        setInputValue('');
        setGoNext(false);
      }
        };

      const useStyles = makeStyles((theme) => ({
            root: {
              '& > *': {
                margin: theme.spacing(1),
                width: '25ch'
              },
            },
          }));
      const classes = useStyles();

      const onKeyDown = (event) => {
        if (event.keyCode === 13) { //13 is the key code for Enter
          event.preventDefault()
          //Here you can even write the logic to select the value from the drop down or something.
        }else if(event.keyCode === 110) 
        {
          event.preventDefault();
        }
      }

    return (
        <div>
          <br /> <br /> <center>
        <br />        
            
        <p>
          <b>You will soon learn if the YouTube videos are removed or not in Stage 2.</b></p>
          <br /> <br />     

        <p>Suppose the videos are <b>NOT</b> removed, and you continue to have the option of clicking <br />on a video and viewing it during the transcription task.</p><br />

        <p>In this situation, how many correct submissions do you expect to get <b>in 15 minutes</b>?</p>

        <form className={classes.root} noValidate autoComplete="off">
            <TextField type="text" id="standard-basic" value={inputValue} onChange= {handleChangeValue} onKeyDown = {onKeyDown}/>
        </form><br /><br />
        </center>
        </div>
    );
}

export default React.memo(Step14);
