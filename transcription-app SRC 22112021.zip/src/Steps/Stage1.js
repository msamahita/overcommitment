import React, { useState, useEffect } from 'react';
import '../components/PracticeStage1.css';
import Button from '@material-ui/core/Button';

import btnA from '../pics/a2.png';
import btnB from '../pics/b2.png';
import btnC from '../pics/c2.png';
import btnD from '../pics/d2.png';
import btnE from '../pics/e2.png';
import btnF from '../pics/f2.png';
import btnG from '../pics/g2.png';
import btnH from '../pics/h2.png';
import btnI from '../pics/i2.png';
import dot from '../pics/k2.png';
import back from '../pics/back.png';

import _btnA from '../pics/a.png';
import _btnB from '../pics/b.png';
import _btnC from '../pics/c.png';
import _btnD from '../pics/d.png';
import _btnE from '../pics/e.png';
import _btnF from '../pics/f.png';
import _btnG from '../pics/g.png';
import _btnH from '../pics/h.png';
import _btnI from '../pics/i.png';
import _dot from '../pics/k.png';

import data from './Data';
import AccessAlarmIcon from '@material-ui/icons/AccessAlarm';
import pad from 'pad-left';
import Modal2 from '../Modal2';

function Stage1({setIsDisabled, handleNext, timerTask}) {
        
    const [count, setCount] = useState(60 * 15);
    const timeLeft = 60 * 15;
    const [getTime, setGetTime] = useState('00:00');
    const [answeredPic, setansweredPic] = useState('');
    const [images, setimages] = useState([]);
    const [pic, setPic] = useState();
    const [completedTasks, setCompletedTasks] = useState(0);   
    const [realData, setRealData] = React.useState('');
    const [answeredCharacter, setAnsweredCharacter] = React.useState(0);
    let character = '';
    let countTime = 0;       
    const [newAnswer, setNewAnswer] = useState([]);
    let count2 = 0;         
    
    const usedRefreshTime = React.useRef(null);
    const usedPauseTime = React.useRef(true);

    const [showBtn, setShowBtn] = React.useState('none');
    
    const newWindow = React.useRef(null);
    //const timerTask = React.useRef();
    const isValidThread = React.useRef(true);

    useEffect(() => {     
        generateValue(); 
        localStorage.setItem('processingStage1', "1");
        localStorage.setItem('processingView1', "1");   

        localStorage.setItem('startedTask1', new Date()); 
        localStorage.setItem('Earnings', 0); 
        localStorage.setItem('CorrectedAnswers1', 0);     
        localStorage.setItem('Tasks1', 0);   
        localStorage.setItem('DurationView', 0);
        localStorage.setItem('LeftTimesMainTab', 0);
        startTimerNow2();
        
        startWatchingPopup();
        setOpen2(true);
        
    }, []);

    useEffect(() => {        
        const unsub = setInterval(() => {            
            countTime++;        
            setCount(timeLeft - countTime);  
            setGetTime(convertToSeconds(timeLeft - countTime));
            if((timeLeft - countTime) <= 0) {
                clearInterval(unsub);
            }
        }, 1000);
        return () => clearInterval(unsub);
    }, []);    

    useEffect(() => {
        if (count <= 0) {             
            clearInterval(timerTask.current);   
            setIsDisabled(true);
            setGetTime('00:00');
            handleNext();  
        }
    }, [count]);

    useEffect(() => {
        if(completedTasks >= 1) 
        {         
            // setIsDisabled(true);
            localStorage.setItem('Tasks1', completedTasks);
        }
    }, [completedTasks]);

    useEffect(() => {            
        window.addEventListener('visibilitychange', downHandler);
        return () => {
        window.removeEventListener('visibilitychange', downHandler);
       }  
    }, []);

    let date1 = new Date();   
    
    const startWatchingPopup = () => {
        timerTask.current = setInterval(() => {
            let n = Number(localStorage.getItem('durationPopupShownTask1'));
            n = n + 1;

            localStorage.setItem('durationPopupShownTask1', n);
        }, 1000);
    }
        
    const downHandler = () => {
        if(document.visibilityState === 'visible') {
            let date2 = new Date();   
            let n = Number(localStorage.getItem('DurationView'));
            n = n + Math.ceil(getDifferenceInSeconds(date1, date2));
            localStorage.setItem('DurationView', n);

            if(isValidThread.current && isValidThread.current === true) startWatchingPopup();
        }
        else {

            date1 = new Date();    
            let n = Number(localStorage.getItem('LeftTimesMainTab'));
            n = n + 1;
            localStorage.setItem('LeftTimesMainTab', n);
            clearInterval(timerTask.current);  
        }
    }
   
    function getDifferenceInSeconds(date1, date2) {
      const diffInMs = Math.abs(date2 - date1);
      return diffInMs / 1000;
    }

    const checkCorrectedCharacters = (i, data) => {
        setNewAnswer([...newAnswer, data]);  
    }

    const addletter = (event) => {
        if (images.length >= 35 && event.target.id !== 'Back') {
            return;
        }               
        
        switch (event.target.id) {
            case 'A':
                setimages([...images, _btnA]);
                setansweredPic(answeredPic => answeredPic + 'a');
                character = 'a';
                checkCorrectedCharacters(+answeredPic.length, character);
                break

            case 'B':
                setimages([...images, _btnB]);
                setansweredPic(answeredPic => answeredPic + 'b');
                character = 'b';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'C':
                setimages([...images, _btnC]);
                setansweredPic(answeredPic => answeredPic + 'c');
                character = 'c';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'D':
                setimages([...images, _btnD]);
                setansweredPic(answeredPic => answeredPic + 'd');
                character = 'd';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'E':
                setimages([...images, _btnE]);
                setansweredPic(answeredPic => answeredPic + 'e');
                character = 'e';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'F':
                setimages([...images, _btnF]);
                setansweredPic(answeredPic => answeredPic + 'f');
                character = 'f';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'G':
                setimages([...images, _btnG]);
                setansweredPic(answeredPic => answeredPic + 'g');
                character = 'g';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'H':
                setimages([...images, _btnH]);
                setansweredPic(answeredPic => answeredPic + 'h');
                character = 'h';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'I':
                setimages([...images, _btnI]);
                setansweredPic(answeredPic => answeredPic + 'i');
                character = 'i';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'Dot':
                setimages([...images, _dot]);
                setansweredPic(answeredPic => answeredPic + '.');
                character = '.';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'Back':

                if (images.length > 0) {
                    images.pop();
                    setimages([...images]);
                    setansweredPic(answeredPic.slice(0, -1));
                    
                    newAnswer.splice(-1,1);
                    setNewAnswer([...newAnswer]);
                }
                else {
                    setNewAnswer([]);
                    setimages([]);
                    setansweredPic('');
                    setAnsweredCharacter(0);
                }
                break

            default:
                break
        }       
    }

    const generateValue = React.useCallback(() => {
        const RandomNumber = Math.floor(Math.random() * 1000) + 1;
        setPic(RandomNumber + '.gif');
        setRealData(data[RandomNumber-1]); 
        setansweredPic('');                                       
    }, []);
    
    const checkAccuracyResponse = () => {
        for(let i =0; i < newAnswer.length; i++){
            if(newAnswer[i] === realData[i]){
                
                count2 = count2 + 1;
            }
        }

        if(count2 >= 32 && count2 <= 35) {
            let oldV = 0;
            
            oldV = Number(localStorage.getItem('CorrectedAnswers1'));


            oldV = oldV + 1;
            localStorage.setItem('CorrectedAnswers1', oldV); 
            if((localStorage.getItem('Com')) === "1"){
               let earnings = oldV * 0.5;  
               localStorage.setItem('Earnings', earnings);
            }
        }           
    }

    const loadPic = () => {
        
        if (images.length < 1) return null;

        usedPauseTime.current = !usedPauseTime.current;
        
        setOpen2(true);
        isValidThread.current = true;
        startTimerNow2();
        startWatchingPopup();

        checkAccuracyResponse();      
      
        setCompletedTasks(prevCompletedTasks => prevCompletedTasks + 1);
        setNewAnswer([]);
        setimages([]);
        setansweredPic([]);
        setAnsweredCharacter(0);
        generateValue();  
    }
    
    const convertToSeconds = (time) => {
        let min = Math.floor( time / 60);
        let sec = time % 60;
        return pad(min, '2', '0') + ':' + pad(sec, '2', '0');
    }

    const [isOpen2, setOpen2] = useState(true);

    const onClose2 = () => {     
        setOpen2(false);     
        setShowBtn('none');  
        isValidThread.current = false;
        clearInterval(timerTask.current);     
    };

    const startTimerNow2 = () =>{
        usedRefreshTime.current = setInterval(() => startTimer2(), 2000);  
    }

    const startTimer2 = () => {   
        clearInterval(usedRefreshTime.current);
        setShowBtn('block');
    }

    return (
        <div className="leftsurvey" > 
            <div>
                <div className="leftsurvey__header">                           
                    <div className="leftsurvey__leftheader">
                        <span>Tasks completed so far: {completedTasks}</span>
                        <span>This work is mandatory to complete the experiment.</span>
                    </div>

                    <div className="leftsurvey__centerheader">
                        <span>Stage 1</span>                    
                    </div>      

                    <div className="leftsurvey__rightheader">
                    <AccessAlarmIcon />
                    <span>
                    {getTime}
                    </span>  

                    </div>                   

                </div>
        
               <div className="leftsurvey__content">
                
                <center>
                
                <div className="leftsurvey__box">                    

                <div className="leftsurvey__contentPicture">
                                
                    <img src={process.env.PUBLIC_URL + `/transcriptionpics/Pic${pic}`} 
                    alt="" className="vertical-center" />
                </div>

                <div className="leftsurvey__contentResponse">
                {/* {character} */}
                {images.map(image => (
                        <img className="picture_info" src={image} alt="Logo"
                         />
                    ))}
                </div>

                <div className="leftsurvey__contentButtons">
                    {completedTasks < 10000 ? ( 
                    <>
                    <img key="A" id="A" onClick={addletter} src={btnA} alt="" />
                    <img key="B" id="B" onClick={addletter} src={btnB} alt="" />
                    <img key="C" id="C" onClick={addletter} src={btnC} alt="" />
                    <img key="D" id="D" onClick={addletter} src={btnD} alt="" />
                    <img key="E" id="E" onClick={addletter} src={btnE} alt="" />
                    <img key="F" id="F" onClick={addletter} src={btnF} alt="" />
                    <img key="G" id="G" onClick={addletter} src={btnG} alt="" />
                    <img key="H" id="H" onClick={addletter} src={btnH} alt="" />
                    <img key="I" id="I" onClick={addletter} src={btnI} alt="" />

                    <img key="Dot" id="Dot" onClick={addletter} src={dot} alt="Dot" />
                    <img key="Back" id="Back" onClick={addletter} src={back} alt="Back" />
                    </>
                    )                    
                    :                    
                    ("")}
                </div>

                <div className="leftsurvey__contentSubmit">
                    {
                        <Button variant="contained" onClick={loadPic} color="primary">
                        Submit
                        </Button>
                    }                    
                </div>
                      
                </div>

                </center>                                  
                
                </div> 

                <div>
                <Modal2 
                    open2={isOpen2} 
                    onClose2= {onClose2}
                    children = {[]} 
                    stage= '1' 
                    newWindow = {newWindow}      
                    showBtn = {showBtn}   
                    >
                </Modal2>
                </div>
                
            </div>   
        </div>
    );
}

export default React.memo(Stage1);