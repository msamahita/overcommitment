import React from 'react';
import './Step12.css';

function Step6({index}) {

    const [response, setResponse] = React.useState('');
    React.useEffect(()=>{
        if(index === "2"){
            if(Number(localStorage.getItem('TranscribedCount2')) >= 32 && Number(localStorage.getItem('TranscribedCount2')) <= 35){
                setResponse('CORRECT');
            }
            else {
                setResponse('INCORRECT');
            }

            if(Number(localStorage.getItem('TranscribedCount3')) >= 32 && Number(localStorage.getItem('TranscribedCount3')) <= 35){
                setResponse('CORRECT');
            }
            else {
                setResponse('INCORRECT');
            }
        }
        else
        {
            if(Number(localStorage.getItem('TranscribedCount')) >= 32 && Number(localStorage.getItem('TranscribedCount')) <= 35){
                setResponse('CORRECT');
            }
            else {
                setResponse('INCORRECT');
            }            
        }
    },[]);
        
    return (
        <div>
            <center>
            <br /><br /><br /><br /><br /><br /><br />
            <p>            
                { index === "2" ?                               
                (
                <>
                <span><b>Practice task 1</b></span><br/><br/>
                  {`You transcribed ${Number(localStorage.getItem('TranscribedCount2'))} characters out of 35 and thus your submission is considered ${response}`}
                <br/><br/><br/><br/>
                <span><b>Practice task 2</b></span><br/><br/>
                {`You transcribed ${Number(localStorage.getItem('TranscribedCount3'))} characters out of 35 and thus your submission is considered ${response}`}

                </>
                )  
                :
                (`You transcribed ${Number(localStorage.getItem('TranscribedCount'))} characters out of 35 and thus your submission is considered ${response}`)                            
                }
            </p>

            <br/>
            <br/>
                {index === "1" ? (
                <p>You will now begin with a real task. Your <b>15 minutes</b> will start as soon as you click the Next button.
                </p>
                ) 
                : 
                ("")
                }
            </center>
        </div>
    );
}

export default React.memo(Step6);