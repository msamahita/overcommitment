import React from 'react';
import image1 from '../pics/stage1image.png';
import './Step4.css';

function Step4() {
    return (
    <div className="step4__content">
           
            <left>
            <h2>STAGE 1</h2>
            </left>
            
            <div>
            <p>During Stage 1, you will be asked to transcribe a line of blurry letters from a Greek text, as shown in the example below.<br /> Each task will be shown on a new screen and consists of a row of blurry Greek text that will appear at the top of the screen.<br /> For each letter, you will need to find and select the corresponding letter from the alternatives presented below the text.<br /> For your task submission to be considered correct, your submission must be at least 90% accurate.</p>
            </div>

            <p>You are asked to complete as many transcription tasks as possible in 15 minutes. Each correct submission will earn you $0.50 <br />(50 cents), should Stage 1 be randomly chosen for payment. After the 15 minutes, you will automatically progress to the next<br /> screen.
            </p>

            <p>Additionally, immediately before each transcription task, there will be a pop-up window which you will have to close to proceed <br /> to the next task. The task clock will continue running while each pop-up (including the very first one) is shown.
            </p>

            <p>You will now have one practice task before moving on to the real tasks. There is no time limit to the practice task. Please note<br /> that the practice task will end once you click Submit.
            </p>  

            <left><img className="step4__img" src={image1} alt ="" /></left>
    
    </div>
    );
}

export default React.memo(Step4);