import React from 'react';
import './Step7.css';

function Step7() {

    const [completedTasks, setCompletedTasks] = React.useState(0); 
    let date2 = new Date();

    function getDifferenceInSeconds(date1, date2) {
        const diffInMs = Math.abs(date2 - date1);
        return diffInMs / 1000;
    }

    React.useEffect(() => {        
        setCompletedTasks(localStorage.getItem('CorrectedAnswers1'));         
        let date1 = Date.parse(localStorage.getItem('startedTask1'));
        let resultTime = Math.ceil(getDifferenceInSeconds(date1, date2)) - 1;    
          
        localStorage.setItem('sessionTimeTask1', resultTime);

        localStorage.removeItem('processingStage1');
        localStorage.removeItem('processingView1');

    }, []);

    return (
        <div className="step7">
            <center>
                <br /><br />
                <br /><br />
                <br /><br />
                <p>Your total number of correct submissions is
                </p>
                <br/>
            <span>{completedTasks}</span></center>
        </div>
    );
}

export default React.memo(Step7);
