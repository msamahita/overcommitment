import React from 'react';
import YouTube from 'react-youtube';
import './YoutubePlayer.css';

import { useLocation } from "react-router-dom";

function YoutubePlayer() {

    let date1 = new Date();
    let date2 = new Date();

    function getDifferenceInSeconds(date1, date2) {
      const diffInMs = Math.abs(date2 - date1);
      return diffInMs / 1000;
    }

    function useQuery() {
      return new URLSearchParams(useLocation().search);
    }
    let query = useQuery();

    let objectVideo = null;

    let timer = React.createRef();
    const ref = React.createRef();

    React.useEffect(() => {
            
      document.title = 'Youtube';      

      window.addEventListener('visibilitychange', downHandler);
      return () => {
      window.removeEventListener('visibilitychange', downHandler);
     }

    }, [])

    const downHandler = () => {
      if(document.visibilityState === 'visible'){
        if(objectVideo) objectVideo.target.playVideo();        
        date1 = new Date();
      }
      else {
        if(objectVideo) objectVideo.target.pauseVideo();
        date2 = new Date();    
        if(query.get("loader") === 'practice') {
          if(query.get("mode") === 'tsk') {
              let n = Number(localStorage.getItem('durationview2YTPractice'));
              n = n + Math.ceil(getDifferenceInSeconds(date1, date2));
              localStorage.setItem('durationview2YTPractice', n);
          }
          else if(query.get("mode") === 'pop') {    
              let n = Number(localStorage.getItem('durationview3YTPractice'));
              n = n + Math.ceil(getDifferenceInSeconds(date1, date2));
              localStorage.setItem('durationview3YTPractice', n);
          }
        }
        else if(query.get("loader") === 'stage2'){
          if(query.get("mode") === 'tsk') {
              let n = Number(localStorage.getItem('durationview2YT'));
              n = n + Math.ceil(getDifferenceInSeconds(date1, date2));
              localStorage.setItem('durationview2YT', n);
          }
          else if(query.get("mode") === 'pop') {
            let n = Number(localStorage.getItem('durationview3YT'));
              n = n + Math.ceil(getDifferenceInSeconds(date1, date2));
              localStorage.setItem('durationview3YT', n);
          }
        }
      }
    }
    
    const opts = {
      height: '640',
      width: '100%',
      playerVars: {
        // https://developers.google.com/youtube/player_parameters
        autoplay: 1,
        controls: 1
      },
    };
    
    const _onReady = (event) => {

      // access to player in all event handlers via event.target      
      event.target.playVideo();
      objectVideo = event;
    }

    const _onPlay = (event) => {}

  const _onPause = (event) => {}
  const _onEnd = (event) => {clearInterval(timer.current);}
  const _onStateChange = (event) => {
    console.info(event.data);

    // if (Number(event.data) < 0) {
    //   //alert('Auto play Video is disabled!\nCan not auto-play\nPlease go to browser settings and enable it.');
    // }    
  }
  
  return (
    <>
      
      <div className="video">
        <YouTube 
          videoId= {query.get("videoId")}
          opts={opts}
          onReady={_onReady} 
          onPlay={_onPlay} 
          onPause={_onPause} 
          onEnd={_onEnd}
          onStateChange = {_onStateChange}
          ref = {ref}          

          />
      </div>
               
    </>
  )
}

export default React.memo(YoutubePlayer);