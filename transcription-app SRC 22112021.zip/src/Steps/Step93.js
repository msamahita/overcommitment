import React from 'react';
import './Step9.css';

function Step93() {
    return (
        <div className="step9__content">
            <br /><p>   <br /> 
No matter if you pay to remove the YouTube videos, keep the videos but never watch them, or keep<br /> the videos and watch any one of them, you will spend the same amount of time (15 minutes) in Stage 2.
</p><br />

<p>    
You will now have a practice round to ensure you understand the process of paying to remove the YouTube videos.<br /> When you have finished the practice round, you will be asked to state your actual price for removing the videos,<br /> as well as answer a few questions about the new transcription task.
</p><br />

<p>    
Finally, the computer will toss the coin. If TAILS comes up, it will then draw a random number to determine the outcome.<br /> You will be informed about whether the YouTube videos will be present or not, and subsequently you will start<br /> the transcription task in Stage 2.
</p>
        </div>
    );
}

export default React.memo(Step93);
