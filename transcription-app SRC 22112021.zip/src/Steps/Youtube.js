import React from 'react';
import data from './Categories';
import CheckBox from './CheckBox';

import './Youtube.css';
import Cookies from 'js-cookie';
import Modal from '../Modal';

function Youtube({setGoNext,typeMsg, setIsDisabled}) {

    const [selectedCat, setSelectedCat] = React.useState([]);
    const [isOpened, setIsOpened] = React.useState(false);

    React.useEffect(()=>{
        if(typeMsg === true)
            setIsOpened(true);
        setGoNext(false);
      },[]);
      
    React.useEffect(() => {
        
        if(selectedCat.length >= 3 && selectedCat.length <= 5){
            setGoNext(true);
        }
        else 
        {
            setGoNext(false);
        }
        if(selectedCat.length >= 3 && selectedCat.length <= 5) {
        Cookies.set('Categories', JSON.stringify(selectedCat));
        localStorage.setItem('Categories', selectedCat);
        }    
        else {
            Cookies.set('Categories', "");
            localStorage.setItem('Categories', []);            
        }
    }, [selectedCat]);

    const msgText3 = <p>As you do not wish to participate in this study, please return your submission on Prolific by selecting the '<b>Stop without completing</b> button.</p>;
        
    return (
        <div className="youtube_main">
            <div>
            <br/><br/><p>The following are <b>YouTube</b> video categories. <b>Please select the 3 to 5 video categories</b> that interest you the most.</p>
            </div>
            
            <div className="youtube_options">
            {                
                data && data.map((element, index) => (
                    element !== '' && <CheckBox index ={index} element= {element}
                    selectedCat = {selectedCat} setSelectedCat= {setSelectedCat}  />                    
                ))
            }
            </div>       
           
        <center>
        <Modal 
        open ={isOpened} 
        onClose={() => setIsOpened(false)}>
        {msgText3}
      </Modal>
        </center>

        </div>

        
    );
}

export default React.memo(Youtube);
