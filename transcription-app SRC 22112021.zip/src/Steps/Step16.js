import React from 'react';
import './Step12.css';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';

function Step16({setGoNext, setIsDisabled}) {

    const [inputValue, setInputValue] = React.useState();
      
    const handleChangeValue = (event) => {
      if(event.target.value >= 0 && event.target.value <= 100){
        setInputValue(event.target.value.replace(/[^0-9]/g, ''));        
        setGoNext(true);
        localStorage.setItem('RevisedRoundPrice', event.target.value);  
      }
      else  {
        setGoNext(false);
        setInputValue('');
      }
        };

    const useStyles = makeStyles((theme) => ({
            root: {
              '& > *': {
                margin: theme.spacing(1),
                width: '25ch'
              },
            },
        }));

    React.useEffect(()=>{
      setGoNext(false);
    },[]);

    const classes = useStyles();

    const onKeyDown = (event) => {
      if (event.keyCode === 13) { //13 is the key code for Enter
        event.preventDefault()
        //Here you can even write the logic to select the value from the drop down or something.
      }else if(event.keyCode === 110) 
      {
        event.preventDefault();
      }
    }


    return (
        <div>
            <center>
            <br />
            <br />
            <br />
            <p>You have previously stated a price of {localStorage.getItem('ActualRoundPrice')} cents for removing the YouTube videos.</p><br />

            <p>You have since answered questions and thought more about the potential outcomes in Stage 2.<br/><br/> Now you have a chance to revise your stated price, if you wish.</p><br />

            <br /><p>Would you like to revise your stated price?
            If yes, please enter a new price between 0 (cents) and 100 (cents) (inclusive). If not,<br /> <br /> simply enter the same price of {localStorage.getItem('ActualRoundPrice')}. <b> This decision is final and cannot be changed!</b></p>

            <form className={classes.root} noValidate autoComplete="off">
          <TextField type="text" id="standard-basic" value={inputValue} onChange= {handleChangeValue} onKeyDown= {onKeyDown} />
          </form><br /><br />
          </center>
        </div>
    );
}

export default React.memo(Step16);
