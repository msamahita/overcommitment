import React from 'react';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import './Step12.css';

function Step15({setGoNext, setIsDisabled}) {

    const [value, setValue] = React.useState('');

    React.useEffect(()=>{
      setGoNext(false);
    },[]);
         
    const handleChange = (event) => {
        setValue(event.target.value);
        if(event.target.value !=='') setGoNext(true);
        else setGoNext(false);
        localStorage.setItem('TemptedClick', event.target.value);  
      };

    return (
        <div>
         <br /><br /> <br /><br /><br /><center>
         <br />   <p>How tempted do you think you would be to click on any of the YouTube videos?</p><br /><br />

            <FormControl>     
                <RadioGroup className="step1__content__MuiFormGroup-root" aria-label="gender" name="gender1" value={value} onChange={handleChange}>
                <FormControlLabel value="Not at all tempted" control={<Radio />} label="Not at all tempted" />
                <FormControlLabel value="Not that tempted" control={<Radio />} label="Not that tempted" />
                <FormControlLabel value="Quite tempted" control={<Radio />} label="Quite tempted" />
                <FormControlLabel value="Very tempted" control={<Radio />} label="Very tempted" />
                </RadioGroup>
            </FormControl>
          </center>
        </div>
    );
}

export default React.memo(Step15);
