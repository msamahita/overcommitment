import React from 'react';
import image2 from '../pics/stage3image.png';
import './Step9.css';
import pad from 'pad-left';

import { Scrollbars } from 'react-custom-scrollbars';

function Step92({setGetTime, setIsDisabled}) {

    const timeToCount = 60;
    const [countTimeX, setCountTimeX] = React.useState(timeToCount * 2);
    const timeLeft =  timeToCount * 2;
    
    let countTime =0;
  
    React.useEffect(() => {       

    const unsub = setInterval(() => { 
      countTime++;        
        setCountTimeX(timeLeft - countTime);  
        setGetTime(convertToSeconds(timeLeft - countTime));
        if((timeLeft - countTime) <= 0) {
            clearInterval(unsub);
        }
    }, 1000);
    return () => clearInterval(unsub);
    }, []); 

    React.useEffect(() => {
    if (countTimeX <= 0) {             
      setGetTime('00:00');
      setIsDisabled(true);
    }
    }, [countTimeX]);

    const convertToSeconds = (time) => {
    let min = Math.floor( time / 60);
    let sec = time % 60;
    return pad(min, '2', '0') + ':' + pad(sec, '2', '0');
    }

    return (
        <div className="step9__content">           
           
           <Scrollbars       
            renderTrackVertical={props => <div {...props} className="track-vertical"/>}
            renderThumbVertical={props => <div {...props} className="thumb-vertical"/>}
            thumbMinSize={80}
            style={{ height: "100%" }}
            >
            <br /><p><b>We would like you to pay attention to the following information, therefore you will not be able to proceed<br /> and the NEXT button will not appear for 2 minutes.</b></p>
           
           <br /><u>Removing the YouTube videos</u>
           
            <p>    
            If you would like to remove the YouTube videos, for example because you think you might be able to better perform<br /> the task without them, you have the possibility to do so. The screen displayed throughout the 15 minutes of Stage 2 will<br /> be exactly the same as in Stage 1, without the YouTube videos. You will still encounter a pop-up before each task<br /> (and the clock will continue running while each pop-up is open), but as in Stage 1 these pop-ups will not contain a YouTube video.
            </p><br />

            <p>We will now describe how to remove the YouTube videos. It is done by paying money taken out of your bonus payment.<br /> <b>Note that there is no right or wrong choice: you are entirely free to state a maximum price that seems best to you</b>.<br /> Starting from the top, determining whether to remove the videos or not involves the following steps:</p>

            <left><img className="step9_img2" src={image2} alt ="screenshot" /></left>

            <p>    
            Example 1. Participant A stated a price of 60 cents and the simulated coin flip came up Heads. Because the coin flip had that result,<br /> the videos will be <b>present</b>, and Participant A will not have to pay anything.
            </p>

            <p>    
            Example 2. Participant B stated a price of 40 cents and the simulated coin flip came up Tails. Because the coin flip had that result,<br /> the computer draws a random number between 0 and 100, removing the videos <b>with 40% probability</b>. The random number <br />drawn was 32 and this is less than 40, so the videos will indeed be removed, and 32 cents will be deducted from Participant<br /> B’s bonus payment.
            </p>

            <p>    
            As you can see, the probability of removing the YouTube videos increases, the higher your stated price. Note in particular that:
            </p>

            <ul>
                <li> Your chance of removing the YouTube videos is maximized (but, due to the simulated coin toss, is not guaranteed) if you<br /> state a price of 100 cents. <b>Note that this maximum price corresponds to the earnings from 2 correctly submitted tasks.</b></li>
                <li> If the videos are removed, you will pay the random number drawn, NOT your price. You will never pay a higher price than <br />the one you state, P. Any amount you pay will be taken out of your bonus payment regardless of whether Stage 1 or 2 is <br />chosen for payment.</li>
                <li>Your total bonus is your earnings from the randomly chosen stage minus any payment to remove the YouTube videos.<br /> Hence, your total bonus may be negative though not lower than -$1. A negative bonus will be taken out of your participation fee.</li>
                <li>If you are not willing to pay anything to remove the YouTube videos, you should enter a price of 0. <br /><b>This will ensure that you will do the transcription task WITH YouTube videos.</b></li>
            </ul><br /><br />
            </Scrollbars>
        </div>
    );
}

export default React.memo(Step92);