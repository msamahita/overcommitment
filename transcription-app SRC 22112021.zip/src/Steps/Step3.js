import React from 'react';
import './Step12.css';

function Step3() {

    return (
        <div>
           
           <br /> <br /> <p>As a reminder, after the session you will receive your participation fee. Additionally, you may receive <br /><b>additional bonus payment depending on your decisions during the study.</b>
            </p><br/>

            <p>The study consists of 2 stages. Out of Stage 1 and Stage 2, only one will be used for payment. Which stage is chosen <br />will be determined by a random draw at the end of the study. Because it is uncertain which stage will be chosen<br /> for payment, you should carefully consider all decisions.
            </p><br/><br/>
            <p>You are about to begin with <b>Stage 1.</b></p>

        </div>
    );
}

export default React.memo(Step3);;
