import React from 'react';
import './Step5.css';
import PracticeStage1 from '../components/PracticeStage1';
import PracticeStage2 from '../components/PracticeStage1';

function Step5({Index, setIsDisabled, handleNext}) {
    return (
        
        <div>
          {Index === "1" ? (
          <PracticeStage1 setIsDisabled = {setIsDisabled} handleNext= {handleNext}/> 
          )
           :
          (
          <PracticeStage2 setIsDisabled = {setIsDisabled} handleNext= {handleNext}/> 
          )}
                          
        </div>   
    );
}

export default React.memo(Step5);