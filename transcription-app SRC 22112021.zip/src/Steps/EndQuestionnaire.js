import React from 'react';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import './Step12.css';
import TextField from '@material-ui/core/TextField';
import './EndQuestionnaire.css';

import { Scrollbars } from 'react-custom-scrollbars';

function EndQuestionnaire({setGoNext, setIsDisabled}) {
       
      const [value, setValue] = React.useState('');
      const handleChange = (event) => {
        setValue(event.target.value);        
        setIsDisabled(true);
        localStorage.setItem('Option1', event.target.value);
      };

      const [value2, setValue2] = React.useState('');    
      const handleChange2 = (event) => {
        setValue2(event.target.value);       
        localStorage.setItem('Option2', event.target.value);
      };

      const [value3, setValue3] = React.useState('');    
      const handleChange3 = (event) => {
        setValue3(event.target.value);        
        localStorage.setItem('SpendTimeOnYoutube', event.target.value); 
      };

      const [valueAge, setvalueAge] = React.useState();
      const handleChangeAgeValue = (event) => {
        if(Number(event.target.value) > -1)  {
          setvalueAge(event.target.value.replace(/[^0-9]/g, ''));   
          localStorage.setItem('Age', event.target.value);
        }
      };

      const [valueGender, setVlueGender] = React.useState();
      const handleChangeGender = (event) => {
          setVlueGender(event.target.value);         
          localStorage.setItem('Gender', event.target.value);
      };

      function getDifferenceInSeconds(date1, date2) {
        const diffInMs = Math.abs(date2 - date1);
        return diffInMs / 1000;
      }

      let date2 = new Date();

      React.useEffect(() => {    
          let date1 = Date.parse(localStorage.getItem('startedTask2'));
          let resultTime = Math.ceil(getDifferenceInSeconds(date1, date2)) - 1;      
          localStorage.setItem('sessionTimeTask2', resultTime);
          localStorage.removeItem('processingStage2');
          localStorage.removeItem('processingYoutube');
          localStorage.removeItem('processingView2');
          localStorage.setItem('Gender', '');
      }, []);

      React.useEffect(()=>{
        setGoNext(false);
      },[]);

      React.useEffect(() => {    
        if(value !==''
        && value2 !=='' 
        && value3 !== ''
        && valueAge !==''
        && Number(valueAge) > -1
        && valueGender !== '') setGoNext(true);
        else setGoNext(false); 

      }, [value, value2, value3, valueAge, valueGender, setGoNext]);

      const onKeyDown = (event) => {
        if (event.keyCode === 13) { //13 is the key code for Enter
          event.preventDefault()
          //Here you can even write the logic to select the value from the drop down or something.
        }else if(event.keyCode === 110) 
        {
          event.preventDefault();
        }
      }

    return (
        <div className="questionnaire__content">
            
            
            <Scrollbars       
            renderTrackVertical={props => <div {...props} className="track-vertical"/>}
            renderThumbVertical={props => <div {...props} className="thumb-vertical"/>}
            thumbMinSize={80}
            style={{ height: "100%" }}
            >


            <h2><b>End questionnaire</b></h2>
            <br />
            
            <p classname="wrap_p"><b>What is your age (in years)?</b></p>
            <div>
              <FormControl className="wrap_radio">
              <TextField type="text" id="standard-basic" value={valueAge} onChange= {handleChangeAgeValue} onKeyDown={onKeyDown} />
              </FormControl>
            </div>

            <br /><br />
            <p className="wrap_p"><b>Do you think the difficulty of ignoring the YouTube videos and concentrating on the transcription task was higher or lower than expected (when you chose your price for removing the videos)?</b></p>
             <div className="end_padding">             
              <FormControl>     
                <RadioGroup className="step1__content__MuiFormGroup-root" aria-label="gender" name="gender1" value={value2} onChange={handleChange2}>
                
                <FormControlLabel value="Ignoring the YouTube videos and concentrating on the transcription task was more difficult than expected" control={<Radio />} label="Ignoring the YouTube videos and concentrating on the transcription task was more difficult than expected" /><br />

                <FormControlLabel value="Ignoring the YouTube videos and concentrating on the transcription task was neither easier nor more difficult than expected" control={<Radio />} label="Ignoring the YouTube videos and concentrating on the transcription task was neither easier nor more difficult than expected" /><br />
                
                <FormControlLabel value="Ignoring the YouTube videos and concentrating on the transcription task was easier than expected" control={<Radio />} label="Ignoring the YouTube videos and concentrating on the transcription task was easier than expected" /><br />

                <FormControlLabel value="N/A - I was not shown the YouTube videos" control={<Radio />} label="N/A - I was not shown the YouTube videos" />
                </RadioGroup>
            </FormControl>
            </div>

            <br />
            <br /><p classname="wrap_p"><b>How much time per day do you spend on YouTube?</b></p>
            <div className="end_padding">
              <FormControl className="wrap_radio">     
                <RadioGroup className="step1__content__MuiFormGroup-root" aria-label="gender" name="gender1" value={value3} onChange={handleChange3}>                
                <FormControlLabel value="Less than 30 minutes" control={<Radio />} label="Less than 30 minutes" />
                <FormControlLabel value="From 30 minutes to 1 hour" control={<Radio />} label="From 30 minutes to 1 hour" />
                <FormControlLabel value="From 1 to 2 hours" control={<Radio />} label="From 1 to 2 hours" />
                <FormControlLabel value="More than 2 hours" control={<Radio />} label="More than 2 hours" />
              
              </RadioGroup>
            </FormControl>
            </div>

            <br />
            <br /><p classname="wrap_p"><b>Which of the following best applies to you?</b></p>
            <div className="end_padding">
              <FormControl className="wrap_radio">     

                <RadioGroup className="step1__content__MuiFormGroup-root" aria-label="gender" name="gender1" value={value} onChange={handleChange}>                

                <FormControlLabel value="I was not interested in the YouTube videos at all because I did not care about them" control={<Radio />} label="I was not interested in the YouTube videos at all because I did not care about them" /><br />

                <FormControlLabel value="I was not interested in the YouTube videos at all because I was concentrating on the transcription task" control={<Radio />} label="I was not interested in the YouTube videos at all because I was concentrating on the transcription task" /><br />

                <FormControlLabel value="At first I was not interested in the YouTube videos, but as time passed, I got bored and started thinking about them" control={<Radio />} label="At first I was not interested in the YouTube videos, but as time passed, I got bored and started thinking about them" /><br />

                <FormControlLabel value="At first I thought a lot about the YouTube videos, but as time passed, I managed to start focusing more on the transcription task" control={<Radio />} label="At first I thought a lot about the YouTube videos, but as time passed, I managed to start focusing more on the transcription task" /><br />

                <FormControlLabel value="I kept thinking about the YouTube videos and this prevented me from staying focused on the transcription task" control={<Radio />} label="I kept thinking about the YouTube videos and this prevented me from staying focused on the transcription task" /><br />

                <FormControlLabel value="I chose to view a YouTube video almost immediately" control={<Radio />} label="I chose to view a YouTube video almost immediately" /><br />

                <FormControlLabel value="N/A - I was not shown the YouTube videos" control={<Radio />} label="N/A - I was not shown the YouTube videos" />
                </RadioGroup>
            </FormControl>
            </div>

            <br />
            <br /><br/>
            </Scrollbars> 
            
        </div>
    );
}

export default React.memo(EndQuestionnaire);
