import React, {useEffect} from 'react';
import './Step11.css';

function Step11({setIsDisabled}) {

    const [isVisible, setIsVisible] = React.useState(true);
    const [makeBottomVisible, setMakeBottomVisible] = React.useState(false);
        
    useEffect(() => {
        loadValue();
            const timer = setTimeout(() => {
                
                if(Math.random() < 0.50) {   
                    localStorage.setItem('CoinToss1', 'HEADS');                 
                    localStorage.setItem('RandomGeneratedNumber1', 0);  
                  } 
                  else {
                    localStorage.setItem('CoinToss1', 'TAILS');                 
                    localStorage.setItem('RandomGeneratedNumber1', Math.floor(Math.random() * 100)+1); 
                  }      
                
                setMakeBottomVisible(true);
                setIsDisabled(true);
                setIsVisible(false);
                
            }, 3000);   
            return () => clearTimeout(timer);
    }, []);

    const loadValue = React.useCallback(() => {
        setIsDisabled(false);
        setIsVisible(true);       
        setMakeBottomVisible(false);
    }, [] )
        
    return (
        <center>
            <div className="step11__content">            

            <br /><h4>The test price you stated is</h4>            
            <span>{localStorage.getItem('PracticeRoundPrice')}</span>            
            <br />
            <p>The coin toss resulted in</p>


            <h3><b>{localStorage.getItem('CoinToss1')}</b></h3>

            {!makeBottomVisible ? ("...") 
            : 
            (
                <>
            <p>Therefore, your test price will {localStorage.getItem('CoinToss1') === 'HEADS' ? 'NOT' : ''} be taken into account</p>

            {
                localStorage.getItem('CoinToss1') === 'HEADS' ? ('') : (
                 <>
                    <p>Given that the coin flip came up TAILS, your chance of removing the YouTube videos is now <br />
                         {localStorage.getItem('PracticeRoundPrice')}%</p>
                 </>
            )
            }            

            {
                localStorage.getItem('CoinToss1') === 'HEADS' ? (<br />) : (
                 <>
                    <p> {isVisible ? `Drawing a random number … ` : ''} </p>  
                 </>
            )
            }

            {
                localStorage.getItem('CoinToss1') === 'HEADS' ? (<br />) : (
                 <>
                    <p> {isVisible ? '' : `The random number drawn is `} <br />{isVisible ? '' : localStorage.getItem('RandomGeneratedNumber1')}</p>
                </>
            )
            }  
            
            <p>
            
            {
            !isVisible ? 
            
            (
                <>
                <p>The outcome for the next stage would have been</p>
                <p><b>Transcription Task
                {localStorage.getItem('CoinToss1') === 'HEADS' ?
                (" WITH ") 
                : 
                (
                    Number(localStorage.getItem('PracticeRoundPrice')                    ) >= Number(localStorage.getItem('RandomGeneratedNumber1')) ? (" WITHOUT ") : (" WITH ")
                )
                }
                Youtube videos</b></p><br />
                </>  
            )
            :            
            ("")
            
            }

            </p>

            <p><b>END OF PRACTICE ROUND</b></p>
            </>
            )
            }           
            
        </div></center>
    );
}

export default React.memo(Step11);