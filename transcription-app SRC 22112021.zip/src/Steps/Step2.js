import React from 'react';
import { GoogleLogin } from 'react-google-login';
import '../Login.css';
import './Step12.css';
import Modal from '../Modal';
import {UserContext} from '../App';
import Cookies from 'js-cookie';

function Step2({setIsDisabled}) {

        const msgText = <p>"As you do not wish to participate in this study, please return your submission on Prolific by selecting the '<b>Stop without completing</b> button."</p>;

        const [userData, setUserData] = React.useContext(UserContext);
        const [isLoggedIn, setIsLoggedIn] = React.useState(false);
        const [isOpened, setIsOpened] = React.useState(false);               

        const onSuccess = (res) => {
            setIsLoggedIn(true);    
            Cookies.set('loggedin', true);            
            setIsDisabled(true);             
            Cookies.set('accessToken', res.tokenObj.access_token);
        }

        const onFailure = ( err) => {
        console.log('Error: ' + err.error);
        setIsLoggedIn(false);
        setIsDisabled(false);
        setUserData({... userData, LoggedIn : false});   
        Cookies.set('loggedin', false);                 
        }

        React.useEffect(() =>{
            Cookies.remove('Videos', { path: '' });
            Cookies.remove('token', { path: '' });
        });

        return (
        <div> <br /> <br /> <center>                                 
                    {
                        !isLoggedIn ? (
                            <>
                            <center>
                            <p>To start the study, please log in to your YouTube account below. When prompted, please agree to the proposed terms. <b>We would like to emphasise that we do NOT collect your login details or any other data related to your account</b>. The purpose of asking you to log in to YouTube and agree to the terms is <b>only</b> to enable showing you some personalised video recommendations later on during the study.
                            </p>
                            </center>
                            
                            <br />
                            </>
                        )
                        :
                        ("")
                    }            

                    {
                        isLoggedIn ? (
                        <center> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <p>
                                <h2>Thank you for logging in. Please click NEXT to continue.</h2>
                            </p></center>
                        )
                        : ("")
                    }

                    <div className="modal">
                        <div className="modal_header">
                        </div>
                            <div className="modal_button">
                                {isLoggedIn ? ("") : (
                                    <GoogleLogin
                                    clientId="790685661700-2icpjl56qbo2635eme8atptkvi18cocu.apps.googleusercontent.com"
                                    buttonText="Login With Google"
                                    onSuccess ={onSuccess}
                                    onFailure = {onFailure}
                                    cookiePolicy={"single_host_origin"}
                                    isSignedIn={isLoggedIn}
                                    scope = 'https://www.googleapis.com/auth/youtube.readonly'
                                    className="modal_button"
                                />
                                )
                                }
                                
                            </div>

                    </div>

                    <Modal open ={isOpened} onClose={() => setIsOpened(false)}>
                        {msgText}
                    </Modal>

                    </center>
        </div>
    );
}

export default Step2;
