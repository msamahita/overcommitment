import React from 'react';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';

function CheckBox({index, element, setSelectedCat, selectedCat}) {

    const [checked, setChecked] = React.useState(false);
    
    const handleChange = (event) => {
        setChecked(event.target.checked);
        
        if(event.target.checked){   
        setSelectedCat([...selectedCat, event.target.name]);
        }
        else {
        setSelectedCat(selectedCat.filter(item => item !== event.target.name)); 
        }        
    };

    return (
        <div>
            <FormControlLabel
            control={<Checkbox checked={checked} onChange={(event) => handleChange(event, index)} name= {element} />}
            label={element} id ={index} name= {index}
          />
        </div>
    );
}

export default CheckBox;
