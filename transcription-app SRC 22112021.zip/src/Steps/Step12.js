import React from 'react';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControl from '@material-ui/core/FormControl';
import './Step12.css';

import Radio from '@material-ui/core/Radio';
import FormControlLabel from '@material-ui/core/FormControlLabel';

function Step12({setGoNext, setIsDisabled}) {

    const [value, setValue] = React.useState('');

    const handleChange = (event) => {
        setValue(event.target.value);
        localStorage.setItem('PreferredYoutubeThumbnails', event.target.value);
        if(event.target.value !== '') setGoNext(true);
        else setGoNext(false);
      };

      React.useEffect(()=>{
        setGoNext(false);
      },[]);

    return (
        <div className="step12__content">
            <br /><p>Before we move on to your actual price, please take a moment to consider what you would prefer for<br /> the upcoming transcription task.</p><br />            

            <FormControl>     
                <RadioGroup className="step1__content__MuiFormGroup-root" aria-label="gender" name="gender1" value={value} onChange={handleChange}>
                <FormControlLabel value="present" control={<Radio />} label="I prefer to do the upcoming transcription task with the YouTube videos" /><b>present</b><br /><br />

                <FormControlLabel value="no present" control={<Radio />} label="I prefer to do the upcoming transcription task with the YouTube videos" /><b>not present</b>
                </RadioGroup>
            </FormControl><br /><br />

            <p>Think about what your choice implies for your price to remove the button on the next screen.</p>

        </div>
    );
}

export default React.memo(Step12);