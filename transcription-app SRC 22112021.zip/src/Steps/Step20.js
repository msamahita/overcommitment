import React from 'react';
import './Step12.css';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';

function Step20({setGoNext, setIsDisabled}) {

         React.useEffect(()=>{
         setGoNext(false);
            },[]);        

        const [inputValue, setInputValue] = React.useState('');
        const [inputValue2, setInputValue2] = React.useState('');
        const [inputValue3, setInputValue3] = React.useState('');
        const [errorValue, setErrorValue] = React.useState('');    
           
        React.useEffect(()=>{
            if(inputValue !== '' && inputValue2 !=='' && inputValue3 !== '')
                setGoNext(true);
                else setGoNext(false);
            },[inputValue, inputValue2, inputValue3]);

        const handleChangeValue = (event) => {        
            if(event.target.value >= 0 && event.target.value <= 100){
                setInputValue(event.target.value.replace(/[^0-9]/g, ''));
            
            setErrorValue('');  
            setIsDisabled(true);    
            localStorage.setItem('LikelyClickOnThumbnails', event.target.value);  
            }
            else {
                
                setIsDisabled(false);
            }
        };

        const handleChangeValue2 = (event) => {
            if(event.target.value >= 0 && event.target.value <= 100){
                setInputValue2(event.target.value.replace(/[^0-9]/g, ''));
                setErrorValue('');
                setIsDisabled(true);
                localStorage.setItem('DoClickExpectedCorrectSubmissions3', event.target.value);
            }
            else {
                setIsDisabled(false);
                setErrorValue('Number must be between 0 and 100');
            }
        };

        const handleChangeValue3 = (event) => {
                if(event.target.value >= 0 && event.target.value <= 100){
                    setInputValue3(event.target.value.replace(/[^0-9]/g, ''));
                    setErrorValue('');
                    setIsDisabled(true);
                    localStorage.setItem('DoNotClickExpectedCorrectSubmissions3', event.target.value);
                }
                else {
                    setIsDisabled(false);
                    setErrorValue('Number must be between 0 and 100');
                }
        };    

        const useStyles = makeStyles((theme) => ({
            root: {
              '& > *': {
                margin: theme.spacing(1),
                width: '25ch'
              },
            },
        }));
    
        const classes = useStyles();

        const onKeyDown = (event) => {
            if (event.keyCode === 13) { //13 is the key code for Enter
              event.preventDefault()
              //Here you can even write the logic to select the value from the drop down or something.
            }else if(event.keyCode === 110) 
            {
              event.preventDefault();
            }
          }

    return (
        <div className="step12__content">
            <br />
            <p classname="wrap_p">
            <b>You will soon learn if the YouTube videos are removed or not in Stage 2.</b>
            </p>
            <br />

            <p classname="wrap_p">Suppose the videos are NOT removed, and you continue to have the option of clicking on a video <br />and viewing it during the transcription task.</p> <br />  <br /> 
            
            <p classname="wrap_p">How likely (in %) would you say you are to click on a video?</p>

            <form className={classes.root} noValidate autoComplete="off">
                <TextField
                id="standard-number"         
                type="text"
                InputLabelProps={{
                shrink: false,
                    }}
                error= {errorValue}
                value={inputValue}
                defaultValue="0%"
                onChange= {handleChangeValue}
                onKeyDown ={onKeyDown}
                />               
            </form>

            <p classname="wrap_p">Suppose that you DO click on a video.
            In this situation, how many correct submissions do you expect<br /> to get in 15 minutes?
            </p>

            <form className={classes.root} noValidate autoComplete="off">
                <TextField
                id="standard-number"         
                type="text"
                InputLabelProps={{
                shrink: false,
                    }}
                error= {errorValue}
                value={inputValue2}
                defaultValue="0"
                onChange= {handleChangeValue2}
                onKeyDown ={onKeyDown}
                />               
            </form>

            <p classname="wrap_p">Suppose that you DO NOT click on a video.
            In this situation, how many correct submissions do you expect<br /> to get in 15 minutes?
            </p>
            
            <form className={classes.root} noValidate autoComplete="off">
                <TextField
                id="standard-number"         
                type="text"
                InputLabelProps={{
                shrink: false,
                    }}
                error= {errorValue}
                value={inputValue3}
                defaultValue="0"
                onChange= {handleChangeValue3}
                onKeyDown ={onKeyDown}
                />               
            </form>

        </div>
    );
}

export default React.memo(Step20);
