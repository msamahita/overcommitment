import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import './EndQuestionnaire2.css';

import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';

import { Scrollbars } from 'react-custom-scrollbars';

function EndQuestionnaire2({setGoNext}) {

    const levels = ['', 'Not at all', 'A little', 'Enough', 'Much', 'Very much'];

    const getTotalBonus = () => {
        
        let totalBonus = 0;
        let earnings = 0;
        let costOfRemove = 0;
        
        if(localStorage.getItem('CoinToss2') === 'HEADS') {                
            earnings = Number(localStorage.getItem('Earnings'));
            costOfRemove =   0;      
            totalBonus = Number(localStorage.getItem('Earnings')); 
        }
        else
        {
            if(Number(localStorage.getItem('RevisedRoundPrice')) >= Number(localStorage.getItem('RandomGeneratedNumber2'))){
            
            earnings = Number(localStorage.getItem('Earnings'));
            costOfRemove =   (Number(localStorage.getItem('RandomGeneratedNumber2')) / 100);  
            totalBonus = earnings - costOfRemove;      
            }
            else {
              earnings = Number(localStorage.getItem('Earnings'));
              costOfRemove =   0;
              totalBonus = Number(localStorage.getItem('Earnings'));   
              //localStorage.setItem('RandomGeneratedNumber2', 0);
            }     
        }
        
        localStorage.setItem('CostOfRemoving', costOfRemove );
        localStorage.setItem('totalBonus', totalBonus );
    }

    React.useEffect(()=>{
        getTotalBonus();
    },[]);    

    React.useEffect(()=>{
        setGoNext(true);
      },[]);

    function getLevel(level) {
        return levels[level-1];
      }
      
    const useStyles = makeStyles({
        root: {
          width: '550',
          padding: '3px'
        },
      });
 
    React.useEffect(()=>{
        setGoNext(false);
      },[]);
    
    const classes = useStyles();

    const [value, setValue] = React.useState('');
    const [value2, setValue2] = React.useState('');
    const [value3, setValue3] = React.useState('');
    const [value4, setValue4] = React.useState('');
    const [value5, setValue5] = React.useState('');
    const [value6, setValue6] = React.useState('');
    const [value7, setValue7] = React.useState('');
    const [value8, setValue8] = React.useState('');
    const [value9, setValue9] = React.useState('');
    const [value10, setValue10] = React.useState('');
    const [value11, setValue11] = React.useState('');
    const [value12, setValue12] = React.useState('');
    const [value13, setValue13] = React.useState('');

    React.useEffect(()=>{
        if(value !== '' &&
        value2 !== '' &&
        value3 !== '' &&
        value4 !== '' &&
        value5 !== '' &&
        value6 !== '' &&
        value7 !== '' &&
        value8 !== '' &&
        value9 !== '' &&
        value10 !== '' &&
        value11 !== '' &&
        value12 !== '' &&
        value13 !== ''
        ) {
            setGoNext(true);
        }
      },[value, value2, value3, value4, value5, value6, value7, value8, value9, value10, value11, value12, value13]);


      const handleChange = (event) => {
        setValue(event.target.value);
        localStorage.setItem('Statement1', event.target.value);  
      };
      const handleChange2 = (event) => {
        setValue2(event.target.value);
        localStorage.setItem('Statement2', event.target.value);  
      };
      const handleChange3 = (event) => {
        setValue3(event.target.value);
        localStorage.setItem('Statement3', event.target.value);  
      };
      const handleChange4 = (event) => {
        setValue4(event.target.value);
        localStorage.setItem('Statement4', event.target.value);  
      };
      const handleChange5 = (event) => {
        setValue5(event.target.value);
       localStorage.setItem('Statement5', event.target.value);  
      };
      const handleChange6 = (event) => {
        setValue6(event.target.value);
         
        localStorage.setItem('Statement6', event.target.value);  
      };
      const handleChange7 = (event) => {
        setValue7(event.target.value);
        localStorage.setItem('Statement7', event.target.value);  
      };
      const handleChange8 = (event) => {
        setValue8(event.target.value);
        localStorage.setItem('Statement8', event.target.value);  
      };
      const handleChange9 = (event) => {
        setValue9(event.target.value);
        localStorage.setItem('Statement9', event.target.value);  
      };
      const handleChange10 = (event) => {
        setValue10(event.target.value);
        localStorage.setItem('Statement10', event.target.value);  
      };
      const handleChange11 = (event) => {
        setValue11(event.target.value);
        localStorage.setItem('Statement11', event.target.value);  
      };
      const handleChange12 = (event) => {
        setValue12(event.target.value);
        localStorage.setItem('Statement12', event.target.value);  
      };
      const handleChange13 = (event) => {
        setValue13(event.target.value);
        localStorage.setItem('Statement13', event.target.value);  
      };

    return (        
            
            <div className="paddingDiv">

<Scrollbars     
            renderTrackVertical={props => <div {...props} className="track-vertical"/>}
            renderThumbVertical={props => <div {...props} className="thumb-vertical"/>}
            thumbMinSize={80}
            style={{ height: "100%" }}
            >
            
            <b><p style= {{paddingLeft: 0, paddingRight: 0}}>Using a 5-point scale, please indicate how much each of the following statements <br/>reflects how you typically are.</p> </b> <br/>     
                        
            <div className={classes.root}>
            <b>I am good at resisting temptation.</b><br/>            
            <FormControl>     
                <RadioGroup className="step1__content__MuiFormGroup-root" aria-label="gender" name="gender1" value={value} onChange={handleChange}>

                <FormControlLabel labelPlacement="bottom" value="1" control={<Radio />} label="1 Not at all"/>
                <FormControlLabel labelPlacement="bottom" value="2" control={<Radio />} label="2"/>
                <FormControlLabel labelPlacement="bottom" value="3" control={<Radio />} label="3"/>
                <FormControlLabel labelPlacement="bottom" value="4" control={<Radio />} label="4"/>
                <FormControlLabel labelPlacement="bottom" value="5" control={<Radio />} label="5 Very much"/>
                
                </RadioGroup>
            </FormControl>            
            </div>
            <br/>
            <div className={classes.root}>
              <b>I have a hard time breaking bad habits.</b><br/>
            <FormControl>     
                <RadioGroup className="step1__content__MuiFormGroup-root" aria-label="gender" name="gender1" value={value2} onChange={handleChange2}>

                <FormControlLabel labelPlacement="bottom" value="1" control={<Radio />} label="1 Not at all"/>
                <FormControlLabel labelPlacement="bottom" value="2" control={<Radio />} label="2"/>
                <FormControlLabel labelPlacement="bottom" value="3" control={<Radio />} label="3"/>
                <FormControlLabel labelPlacement="bottom" value="4" control={<Radio />} label="4"/>
                <FormControlLabel labelPlacement="bottom" value="5" control={<Radio />} label="5 Very much"/>
                
                </RadioGroup>
            </FormControl>   
            </div>
            <br/>
            <div className={classes.root}>
              <b>I am lazy.</b><br/>
            <FormControl>     
                <RadioGroup className="step1__content__MuiFormGroup-root" aria-label="gender" name="gender1" value={value3} onChange={handleChange3}>

                <FormControlLabel labelPlacement="bottom" value="1" control={<Radio />} label="1 Not at all"/>
                <FormControlLabel labelPlacement="bottom" value="2" control={<Radio />} label="2"/>
                <FormControlLabel labelPlacement="bottom" value="3" control={<Radio />} label="3"/>
                <FormControlLabel labelPlacement="bottom" value="4" control={<Radio />} label="4"/>
                <FormControlLabel labelPlacement="bottom" value="5" control={<Radio />} label="5 Very much"/>
                
                </RadioGroup>
            </FormControl>   
            </div>
            <br/>
            <div className={classes.root}>
              <b>I say inappropriate things.</b><br/>
            <FormControl>     
                <RadioGroup className="step1__content__MuiFormGroup-root" aria-label="gender" name="gender1" value={value4} onChange={handleChange4}>

                <FormControlLabel labelPlacement="bottom" value="1" control={<Radio />} label="1 Not at all"/>
                <FormControlLabel labelPlacement="bottom" value="2" control={<Radio />} label="2"/>
                <FormControlLabel labelPlacement="bottom" value="3" control={<Radio />} label="3"/>
                <FormControlLabel labelPlacement="bottom" value="4" control={<Radio />} label="4"/>
                <FormControlLabel labelPlacement="bottom" value="5" control={<Radio />} label="5 Very much"/>
                
                </RadioGroup>
            </FormControl>   
            </div>
            <br/>
            <div className={classes.root}>
              <b>I refuse things that are bad for me.</b><br/>
            <FormControl>     
                <RadioGroup className="step1__content__MuiFormGroup-root" aria-label="gender" name="gender1" value={value5} onChange={handleChange5}>

                <FormControlLabel labelPlacement="bottom" value="1" control={<Radio />} label="1 Not at all"/>
                <FormControlLabel labelPlacement="bottom" value="2" control={<Radio />} label="2"/>
                <FormControlLabel labelPlacement="bottom" value="3" control={<Radio />} label="3"/>
                <FormControlLabel labelPlacement="bottom" value="4" control={<Radio />} label="4"/>
                <FormControlLabel labelPlacement="bottom" value="5" control={<Radio />} label="5 Very much"/>
                
                </RadioGroup>
            </FormControl>   
            </div>
            <br/>
            <div className={classes.root}>
              <b>I wish I had more self-discipline.</b><br/>
            <FormControl>     
                <RadioGroup className="step1__content__MuiFormGroup-root" aria-label="gender" name="gender1" value={value6} onChange={handleChange6}>

                <FormControlLabel labelPlacement="bottom" value="1" control={<Radio />} label="1 Not at all"/>
                <FormControlLabel labelPlacement="bottom" value="2" control={<Radio />} label="2"/>
                <FormControlLabel labelPlacement="bottom" value="3" control={<Radio />} label="3"/>
                <FormControlLabel labelPlacement="bottom" value="4" control={<Radio />} label="4"/>
                <FormControlLabel labelPlacement="bottom" value="5" control={<Radio />} label="5 Very much"/>
                
                </RadioGroup>
            </FormControl>   
            </div>
            <br/>
            <div className={classes.root}>
              <b>I do certain things that are bad for me, if they are fun.</b><br/>
            <FormControl>     
                <RadioGroup className="step1__content__MuiFormGroup-root" aria-label="gender" name="gender1" value={value7} onChange={handleChange7}>

                <FormControlLabel labelPlacement="bottom" value="1" control={<Radio />} label="1 Not at all"/>
                <FormControlLabel labelPlacement="bottom" value="2" control={<Radio />} label="2"/>
                <FormControlLabel labelPlacement="bottom" value="3" control={<Radio />} label="3"/>
                <FormControlLabel labelPlacement="bottom" value="4" control={<Radio />} label="4"/>
                <FormControlLabel labelPlacement="bottom" value="5" control={<Radio />} label="5 Very much"/>

                </RadioGroup>
            </FormControl>   
            </div>
            <br/>
            <div className={classes.root}>
              <b>Pleasure and fun sometimes keep me from getting work done.</b><br/>
            <FormControl>     
                <RadioGroup className="step1__content__MuiFormGroup-root" aria-label="gender" name="gender1" value={value8} onChange={handleChange8}>

                <FormControlLabel labelPlacement="bottom" value="1" control={<Radio />} label="1 Not at all"/>
                <FormControlLabel labelPlacement="bottom" value="2" control={<Radio />} label="2"/>
                <FormControlLabel labelPlacement="bottom" value="3" control={<Radio />} label="3"/>
                <FormControlLabel labelPlacement="bottom" value="4" control={<Radio />} label="4"/>
                <FormControlLabel labelPlacement="bottom" value="5" control={<Radio />} label="5 Very much"/>
                </RadioGroup>
            </FormControl>   
            </div>
            <br/>
            <div className={classes.root}>
              <b>I have trouble concentrating.</b><br/>
            <FormControl>     
                <RadioGroup className="step1__content__MuiFormGroup-root" aria-label="gender" name="gender1" value={value9} onChange={handleChange9}>

                <FormControlLabel labelPlacement="bottom" value="1" control={<Radio />} label="1 Not at all"/>
                <FormControlLabel labelPlacement="bottom" value="2" control={<Radio />} label="2"/>
                <FormControlLabel labelPlacement="bottom" value="3" control={<Radio />} label="3"/>
                <FormControlLabel labelPlacement="bottom" value="4" control={<Radio />} label="4"/>
                <FormControlLabel labelPlacement="bottom" value="5" control={<Radio />} label="5 Very much"/>
                
                </RadioGroup>
            </FormControl>   
            </div>
            <br/>
            <div className={classes.root}>
              <b>I am able to work effectively toward long-term goals.</b><br/>
            <FormControl>     
                <RadioGroup className="step1__content__MuiFormGroup-root" aria-label="gender" name="gender1" value={value10} onChange={handleChange10}>

                <FormControlLabel labelPlacement="bottom" value="1" control={<Radio />} label="1 Not at all"/>
                <FormControlLabel labelPlacement="bottom" value="2" control={<Radio />} label="2"/>
                <FormControlLabel labelPlacement="bottom" value="3" control={<Radio />} label="3"/>
                <FormControlLabel labelPlacement="bottom" value="4" control={<Radio />} label="4"/>
                <FormControlLabel labelPlacement="bottom" value="5" control={<Radio />} label="5 Very much"/>
                </RadioGroup>
            </FormControl>   
            </div>
            <br/>
            <div className={classes.root}>
              <b>People would say that I have iron self-discipline.</b><br/>
            <FormControl>     
                <RadioGroup className="step1__content__MuiFormGroup-root" aria-label="gender" name="gender1" value={value11} onChange={handleChange11}>

                <FormControlLabel labelPlacement="bottom" value="1" control={<Radio />} label="1 Not at all"/>
                <FormControlLabel labelPlacement="bottom" value="2" control={<Radio />} label="2"/>
                <FormControlLabel labelPlacement="bottom" value="3" control={<Radio />} label="3"/>
                <FormControlLabel labelPlacement="bottom" value="4" control={<Radio />} label="4"/>
                <FormControlLabel labelPlacement="bottom" value="5" control={<Radio />} label="5 Very much"/>
                
                </RadioGroup>
            </FormControl>   
            </div>
            <br/>
            <div className={classes.root}>
              <b>Sometimes I can’t stop myself from doing something, even if I know it is wrong.</b><br/>
            <FormControl>     
                <RadioGroup className="step1__content__MuiFormGroup-root" aria-label="gender" name="gender1" value={value12} onChange={handleChange12}>

                <FormControlLabel labelPlacement="bottom" value="1" control={<Radio />} label="1 Not at all"/>
                <FormControlLabel labelPlacement="bottom" value="2" control={<Radio />} label="2"/>
                <FormControlLabel labelPlacement="bottom" value="3" control={<Radio />} label="3"/>
                <FormControlLabel labelPlacement="bottom" value="4" control={<Radio />} label="4"/>
                <FormControlLabel labelPlacement="bottom" value="5" control={<Radio />} label="5 Very much"/>
                
                </RadioGroup>
            </FormControl>   
            </div>
            <br/>
            <div className={classes.root}>
              <b>I often act without thinking through all the alternatives.</b><br/>
            <FormControl>     
                <RadioGroup className="step1__content__MuiFormGroup-root" aria-label="gender" name="gender1" value={value13} onChange={handleChange13}>
                <FormControlLabel labelPlacement="bottom" value="1" control={<Radio />} label="1 Not at all"/>
                <FormControlLabel labelPlacement="bottom" value="2" control={<Radio />} label="2"/>
                <FormControlLabel labelPlacement="bottom" value="3" control={<Radio />} label="3"/>
                <FormControlLabel labelPlacement="bottom" value="4" control={<Radio />} label="4"/>
                <FormControlLabel labelPlacement="bottom" value="5" control={<Radio />} label="5 Very much"/>
                
                </RadioGroup>
            </FormControl>   
            </div>
           
            <br/>
            <br/>

            </Scrollbars> 

        </div>    
    );
}

export default React.memo(EndQuestionnaire2);