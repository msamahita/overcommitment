import React from 'react';
import './Step9.css';
import pad from 'pad-left';

import { Scrollbars } from 'react-custom-scrollbars';

function Step9({setGetTime, setIsDisabled}) {
    
  const timeToCount = 60;
  const [countTimeX, setCountTimeX] = React.useState(timeToCount * 2);
  const timeLeft =  timeToCount * 2;
    
    let countTime =0;
  
    React.useEffect(() => {       

    const unsub = setInterval(() => { 
      countTime++;        
        setCountTimeX(timeLeft - countTime);  
        setGetTime(convertToSeconds(timeLeft - countTime));
        if((timeLeft - countTime) <= 0) {
            clearInterval(unsub);
        }
    }, 1000);
    return () => clearInterval(unsub);
    }, []); 

    React.useEffect(() => {
    if (countTimeX <= 0) {             
      setGetTime('00:00');
      setIsDisabled(true);
    }
    }, [countTimeX]);

    const convertToSeconds = (time) => {
    let min = Math.floor( time / 60);
    let sec = time % 60;
    return pad(min, '2', '0') + ':' + pad(sec, '2', '0');
    }

    return (
        <div className="step9__content">
           
           <Scrollbars       
            renderTrackVertical={props => <div {...props} className="track-vertical"/>}
            renderThumbVertical={props => <div {...props} className="thumb-vertical"/>}
            thumbMinSize={80}
            style={{ height: "100%" }} >

           <left>
            <h2>STAGE 2</h2>
            </left>

           <p><b>We would like you to pay attention to the following information, therefore you will not be able to proceed<br /> and the NEXT button will not appear for 2 minutes.</b></p>
           
           <p>
           In Stage 2, you will repeat the same task, with one modification. We will explain this modification in more detail soon,<br /> and afterwards you will be asked to answer some questions regarding the new task.
          </p> 


          <u>The modification
          </u>

          <p>
          The task in Stage 2 is similar to the one you completed in Stage 1: you will be asked to transcribe as many lines of blurry<br /> Greek letters as possible within 15 minutes. You will again earn $0.50 (50 cents) per correct (90% accuracy) submission, <br />should Stage 2 be randomly selected for payment. After the 15 minutes, you will automatically progress to the next screen.
          </p>

          <p>
          However, below the transcription task, there will now be a series of 10 YouTube videos, as shown on the next screen.<br /> The videos on your screen will be personalised for you by importing YouTube videos from your chosen categories<br /> that are currently trending in the US. A new set of 10 videos from your chosen categories will be shown for each<br /> new transcription task. You can click on any YouTube video at any point during the task.
          </p>

          <p>
          Immediately before each transcription task, there will again be a pop-up window which now <b>automatically plays one of <br />the videos that will appear below the task.</b> You will have to close the pop-up window to proceed <br />to the next task. The task clock will continue running while each pop-up (including the very first one) is shown.

          </p>

          <p>
          <b>We do NOT record which YouTube videos you see or view. We only record <u>whether clicks are made</u> on any video.</b>
          </p>

          <p>If you click on a video, a new tab will open where you will be able to view it. You can watch the video<br /> for as long as you like and come back to the transcription task tab at any time, and you can subsequently click on another<br /> video if you like. However, the task clock will keep running while you are watching any video. If 15 minutes elapsed while<br /> you are viewing a video, the video tab will automatically close and you will be taken back to the study tab.
          </p>

          <p>    
          Watching videos means that you spend less time on the transcription task. Hence, you may potentially<br /> have fewer correct submissions in the 15-minute period, thus lowering your bonus payment. If you do not click on any video,<br /> you will simply continue with the transcription task.
          </p>

          <p>In the next screen, you will practice the transcription task with the new modification: the addition of the YouTube videos. <br />To help you to familiarize yourself with the new setup, you will now face <b>two</b> practice tasks in a row.
          </p>
          <br /><br />
          </Scrollbars>

          </div>
              );
          }
export default React.memo(Step9);