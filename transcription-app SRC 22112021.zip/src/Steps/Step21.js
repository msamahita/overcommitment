import React from 'react';
import './Step9.css';

import { makeStyles } from '@material-ui/core/styles';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';

function Step21({setGoNext}) {
    
    const [inputValue, setInputValue] = React.useState();
    
    React.useEffect(()=>{
        setGoNext(true);
    },[]);

    const handleChangeValue = (event) => {
        setInputValue(event.target.value);
        
        if(event.target.value !== ''){                        
            setGoNext(true);
            localStorage.setItem('MyExperienceComment', event.target.value);
        }
        else {
            setGoNext(false);
        }
    };

    const useStyles = makeStyles((theme) => ({
        root: {
          '& > *': {
            margin: theme.spacing(1),
            width: '25ch'
          },
        },
    }));

    const classes = useStyles();

    const onKeyDown = (event) => {
        if (event.keyCode === 13) { //13 is the key code for Enter
          event.preventDefault()
          //Here you can even write the logic to select the value from the drop down or something.
        }else if(event.keyCode === 110) 
        {
          event.preventDefault();
        }
      }


    return (
        <div className="step9__content">   
            <br />
            <br />
            <br />
            <p>We would be very interested in hearing about your experience in this study.<br /><br /> Please write any comment in the textbox below.</p>
            <br /><br />

                <TextareaAutosize
                    rowsMin={5}
                    cols ={80}
                    rowsMax = {10}
                    aria-label="empty textarea"
                    placeholder="Please write any comment"
                    value = {inputValue}
                    onChange = {handleChangeValue}
                    onKeyDown ={onKeyDown}
                />
         </div>
    )
}

export default React.memo(Step21);