import React, { useState, useEffect } from 'react';
import '../components/PracticeStage1.css';
import Button from '@material-ui/core/Button';

import btnA from '../pics/a2.png';
import btnB from '../pics/b2.png';
import btnC from '../pics/c2.png';
import btnD from '../pics/d2.png';
import btnE from '../pics/e2.png';
import btnF from '../pics/f2.png';
import btnG from '../pics/g2.png';
import btnH from '../pics/h2.png';
import btnI from '../pics/i2.png';
import dot from '../pics/k2.png';
import back from '../pics/back.png';

import _btnA from '../pics/a.png';
import _btnB from '../pics/b.png';
import _btnC from '../pics/c.png';
import _btnD from '../pics/d.png';
import _btnE from '../pics/e.png';
import _btnF from '../pics/f.png';
import _btnG from '../pics/g.png';
import _btnH from '../pics/h.png';
import _btnI from '../pics/i.png';
import _dot from '../pics/k.png';


import data from './Data';
import AccessAlarmIcon from '@material-ui/icons/AccessAlarm';
import pad from 'pad-left';

import Modal2 from '../Modal2';

function Stage2({setIsDisabled, handleNext, timerTask2}) {
        
    const [videos, setVideos] = useState([]);

    const [count, setCount] = useState(60* 15);    
    const timeLeft =  60 * 15;
    const [getTime, setGetTime] = useState('00:00');
    const [answeredPic, setansweredPic] = useState('');
    const [images, setimages] = useState([]);
    const [pic, setPic] = useState();
    const [completedTasks, setCompletedTasks] = useState(0);   
    const [realData, setRealData] = React.useState('');
    const [answeredCharacter, setAnsweredCharacter] = React.useState(0);
    let character = '';
    let countTime = 0;     
    const [newArray, setNewArray] = React.useState([]);
    
    let tempArr = React.useRef([]);
    const [newAnswer, setNewAnswer] = useState([]);

    let count2 = 0;    
    
    const usedRefreshTime = React.useRef(null);
    const usedPauseTime = React.useRef(true);
    
    const [isOpen2, setOpen2] = useState(false);

    const newWindow = React.useRef(null);
 
    const usedRefreshTime2 = React.useRef(null);
    const [showBtn, setShowBtn] = React.useState('none');

    const isValidThread = React.useRef(true);

    const onClose2 = () => {                
        setOpen2(false);
        setShowBtn('none');  
        isValidThread.current = false;
        usedPauseTime.current = !usedPauseTime.current; 
        clearInterval(timerTask2.current);               
    };

    const startTimer = () => {            
        if(true) {
            countTime++;    
            setCount(timeLeft - countTime);  
            setGetTime(convertToSeconds(timeLeft - countTime));
            if(((timeLeft - countTime) <= 0)) {
                clearInterval(usedRefreshTime.current);
            }
        }else return;
    }

    const startTimerNow = () =>{
        usedRefreshTime.current = setInterval(() => startTimer(), 1000);  
    }

    useEffect(() => {        
        setIsDisabled(false);    
        setNewArray([]);        
        generateValue();     

        localStorage.setItem('processingStage2', "1");   
        localStorage.setItem('processingView2', "1");   

        localStorage.setItem('startedTask2', new Date());

        if((localStorage.getItem('Com')) === "2"){
            localStorage.setItem('Earnings', 0); 
        }
        localStorage.setItem('CorrectedAnswers2', 0);     
        localStorage.setItem('Tasks2', 0);   

        localStorage.setItem('DurationView2', 0);
        localStorage.setItem('LeftTimesMainTab2', 0);

        startWatchingPopup();
        setOpen2(true);         
        
    }, []);    

    useEffect(() =>{
        
        const unsub = setInterval(() => {            
        const data = localStorage.getItem('videos');
        let count = localStorage.getItem('count');
        setVideos([]);
        
        let RevisedRoundPrice = Number(localStorage.getItem('RevisedRoundPrice'));
        let RandomGeneratedNumber2 = Number(localStorage.getItem('RandomGeneratedNumber2'));
        let CoinToss2 = (localStorage.getItem('CoinToss2'));


        if(CoinToss2 !== 'TAILS' || (RevisedRoundPrice < RandomGeneratedNumber2)){

        tempArr.current = JSON.parse(data);
        
        let tempA =[];

        if(tempArr.current && tempArr.current.length >0) {
            
            for(let i = Number(count); i < (Number(count) + 10) ; i++) {
                tempA.push(tempArr.current[i]);
            }            
            
            setVideos(tempA);

            count = Number(count) + (10);
            localStorage.setItem('count', count);                       
        }
    }
        clearInterval(unsub);         

        }, 2000);
        return () => clearInterval(unsub);     
    }, []);
    
    useEffect(() => {         
        startTimerNow();  
        startTimerNow2();
    }, []);

    useEffect(() => {
        if (count <= 0) {       
            clearInterval(timerTask2.current);   
            closeTab();  
            setIsDisabled(true);
            setGetTime('00:00');
            handleNext();  
        }
    }, [count]);    
    
    useEffect(() => {
        if(completedTasks >= 1) 
        {            
            // setIsDisabled(true);
            localStorage.setItem('Tasks2', completedTasks);          
        }        
    }, [completedTasks]);
    
    useEffect(() => {            
        window.addEventListener('visibilitychange', downHandler);
        return () => {
        window.removeEventListener('visibilitychange', downHandler);
       }  
    }, []);

    let date1 = new Date();    

    const startWatchingPopup = () => {
        timerTask2.current = setInterval(() => {
            let n = Number(localStorage.getItem('durationPopupShown'));
            n = n + 1;

            localStorage.setItem('durationPopupShown', n);
        }, 1000);
    }
    
    const downHandler = () => {
        if(document.visibilityState === 'visible') {
            let date2 = new Date();   
            let n = Number(localStorage.getItem('DurationView2'));
            n = n + Math.ceil(getDifferenceInSeconds(date1, date2));
            localStorage.setItem('DurationView2', n);
            
            console.clear();
            console.log(isOpen2 + '/' + isValidThread.current);
            if(isValidThread.current && isValidThread.current === true) startWatchingPopup();
        }
        else {

            date1 = new Date(); 

            let n = Number(localStorage.getItem('LeftTimesMainTab2'));
            n = n + 1;
            localStorage.setItem('LeftTimesMainTab2', n);
            clearInterval(timerTask2.current);   
        }
    }

    function getDifferenceInSeconds(date1, date2) {
        const diffInMs = Math.abs(date2 - date1);
        return diffInMs / 1000;
    }

    const checkCorrectedCharacters = (i, data) => {
        setNewAnswer([...newAnswer, data]);  
    }

    const addletter = (event) => {
        if (images.length >= 35 && event.target.id !== 'Back') {
            return;
        }               
        
        switch (event.target.id) {
            case 'A':
                setimages([...images, _btnA]);
                setansweredPic(answeredPic => answeredPic + 'a');
                character = 'a';
                checkCorrectedCharacters(+answeredPic.length, character);
                break

            case 'B':
                setimages([...images, _btnB]);
                setansweredPic(answeredPic => answeredPic + 'b');
                character = 'b';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'C':
                setimages([...images, _btnC]);
                setansweredPic(answeredPic => answeredPic + 'c');
                character = 'c';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'D':
                setimages([...images, _btnD]);
                setansweredPic(answeredPic => answeredPic + 'd');
                character = 'd';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'E':
                setimages([...images, _btnE]);
                setansweredPic(answeredPic => answeredPic + 'e');
                character = 'e';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'F':
                setimages([...images, _btnF]);
                setansweredPic(answeredPic => answeredPic + 'f');
                character = 'f';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'G':
                setimages([...images, _btnG]);
                setansweredPic(answeredPic => answeredPic + 'g');
                character = 'g';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'H':
                setimages([...images, _btnH]);
                setansweredPic(answeredPic => answeredPic + 'h');
                character = 'h';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'I':
                setimages([...images, _btnI]);
                setansweredPic(answeredPic => answeredPic + 'i');
                character = 'i';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'Dot':
                setimages([...images, _dot]);
                setansweredPic(answeredPic => answeredPic + '.');
                character = '.';
                checkCorrectedCharacters(answeredPic.length, character);
                break

            case 'Back':

                if (images.length > 0) {
                    images.pop();
                    setimages([...images]);
                    setansweredPic(answeredPic.slice(0, -1));
                    newAnswer.splice(-1,1);
                    setNewAnswer([...newAnswer]);
                }
                else {
                    setNewAnswer([]);
                    setimages([]);
                    setansweredPic('');
                    setAnsweredCharacter(0);
                }
                break

            default:
                break
        }       
    }

    const generateValue = React.useCallback(() => {
        const RandomNumber = Math.floor(Math.random() * 1000) + 1;
        setPic(RandomNumber + '.gif');
        setRealData(data[RandomNumber-1]); 
        setansweredPic('');                                       
    }, []);

    const checkAccuracyResponse = () => {
        for(let i =0; i < newAnswer.length; i++){
            if(newAnswer[i] === realData[i]){
                
                count2 = count2 + 1;
            }
        }
        
        if(count2 >= 32 && count2 <= 35) {
            let oldV = 0;
            
            oldV = Number(localStorage.getItem('CorrectedAnswers2'));


            oldV = oldV + 1;
            localStorage.setItem('CorrectedAnswers2', oldV); 
            if((localStorage.getItem('Com')) === "2"){
               let earnings = oldV * 0.5;  
               localStorage.setItem('Earnings', earnings);
            }
        }            
    }
    
    const loadPic = (event) => {
                   
        if (images.length < 1) return null;
        
        shiftVideos();

        usedPauseTime.current = !usedPauseTime.current;
        setOpen2(true);
        isValidThread.current = true;
        startTimerNow2();
        startWatchingPopup();

        checkAccuracyResponse();      
      
        setCompletedTasks(prevCompletedTasks => prevCompletedTasks + 1);
        setNewAnswer([]);
        setimages([]);
        setansweredPic([]);
        setAnsweredCharacter(0);
        generateValue();                   
    }
    
    const shiftVideos = () => {
                  
        const data = localStorage.getItem('videos');
        let count = localStorage.getItem('count');      

        if(!tempArr.current) return;
        if(Number(count) >= Math.ceil(tempArr.current.length/10) * 10) return;
        
        let RevisedRoundPrice = Number(localStorage.getItem('RevisedRoundPrice'));
        let RandomGeneratedNumber2 = Number(localStorage.getItem('RandomGeneratedNumber2'));
        let CoinToss2 = (localStorage.getItem('CoinToss2'));

        if(CoinToss2 !== 'TAILS' || (RevisedRoundPrice < RandomGeneratedNumber2)){
        tempArr.current = JSON.parse(data);        
        let tempA =[];        
                
        if(tempArr.current && tempArr.current.length >0) {
            for(let i = Number(count); i < (Number(count) + 10) ; i++) {
                tempA.push(tempArr.current[i]);
            }            
            
            setVideos(tempA);

            count = Number(count) + (10);
            localStorage.setItem('count', count);
            
            }
        }

    }
    
    const convertToSeconds = (time) => {
        let min = Math.floor( time / 60);
        let sec = time % 60;
        return pad(min, '2', '0') + ':' + pad(sec, '2', '0');
    }

    const closeTab = () => {
        if(newWindow.current) {
            newWindow.current.close();              
        }
    }
    
    const getVideo = (e, videoId) => {            
        e.preventDefault();        
        newWindow.current = window.open("/youtubeplayer?videoId=" + videoId +"&mode=tsk&loader=stage2", "_blank");
        let n = Number(localStorage.getItem('ClickedThumbnailsTab'));
        n= n + 1;
        localStorage.setItem('ClickedThumbnailsTab', n);
    }

    const startTimerNow2 = () =>{
        usedRefreshTime2.current = setInterval(() => startTimer2(), 2000);  
    }

    const startTimer2 = () => {   
        clearInterval(usedRefreshTime2.current);
        setShowBtn('block');
    }
    
    return (
        <div className="leftsurvey" >         
            <div>
                <div className="leftsurvey__header">                           
                    <div className="leftsurvey__leftheader">
                        <span>Tasks completed so far: {completedTasks}</span>
                        <span>This work is mandatory to complete the experiment.</span>
                    </div>

                    <div className="leftsurvey__centerheader">
                    <span>Stage 2</span>                     
                    </div>      

                    <div className="leftsurvey__rightheader">
                    <AccessAlarmIcon />
                    <span>
                    {getTime}
                    </span>                  
                    </div>                   

                </div>
        
               <div className="leftsurvey__content">
                
                <center>
                
                <div className="leftsurvey__box">                

                <div className="leftsurvey__contentPicture">
                {/* {clickedTimes} */}
                 <img src={process.env.PUBLIC_URL + `/transcriptionpics/Pic${pic}`} 
                    alt="" className="vertical-center" />
                </div>

                <div className="leftsurvey__contentResponse">
                {/* {character} */}
                {images.map(image => (
                        <img className="picture_info" src={image} alt="Logo"
                         />
                    ))}
                </div>

                <div className="leftsurvey__contentButtons">
                    {completedTasks < 10000 ? ( 
                    <>
                    <img key="A" id="A" onClick={addletter} src={btnA} alt="" />
                    <img key="B" id="B" onClick={addletter} src={btnB} alt="" />
                    <img key="C" id="C" onClick={addletter} src={btnC} alt="" />
                    <img key="D" id="D" onClick={addletter} src={btnD} alt="" />
                    <img key="E" id="E" onClick={addletter} src={btnE} alt="" />
                    <img key="F" id="F" onClick={addletter} src={btnF} alt="" />
                    <img key="G" id="G" onClick={addletter} src={btnG} alt="" />
                    <img key="H" id="H" onClick={addletter} src={btnH} alt="" />
                    <img key="I" id="I" onClick={addletter} src={btnI} alt="" />

                    <img key="Dot" id="Dot" onClick={addletter} src={dot} alt="Dot" />
                    <img key="Back" id="Back" onClick={addletter} src={back} alt="Back" />
                    </>
                    )                    
                    :                    
                    ("")}
                </div>

                <div className="leftsurvey__contentSubmit">
                    {
                        <Button variant="contained" onClick={(e) => loadPic(e)} color="primary">
                        Submit
                        </Button>
                    }                    
                </div>
                
                <div className="leftsurvey__sidebar2">    
                    
                    {  
                        videos.length >0 && videos.map((video, index) => (
                        <>
                            
                            {index < 5 ? (<div className="topShow">
                            <>
                            <img 
                            className="leftsurvey__sidebar_img2" 
                            src={video.Thumbnail} 
                            alt= { video.VideoId }
                            title = {video.Title }
                            key = {video.VideoId} 
                            onClick= {(e) => getVideo(e, video.VideoId)}
                            />
                            <span className="descriptionClass2 limtiCharClass">{video.Title}
                            </span>
                            </>
                            </div>) : ("")}
                            

                            {index > 4 ? (<div className="downShow">
                            <>
                            <img 
                            className="leftsurvey__sidebar_img2" 
                            src={video.Thumbnail} 
                            alt= { video.VideoId }
                            title = {video.Title }
                            key = {video.VideoId} 
                            onClick= {(e) => getVideo(e, video.VideoId)}
                            />
                            <span className="descriptionClass2 limtiCharClass">{video.Title}
                            </span>
                            </>
                            </div>) : ("")}                                                     

                        </>
                        ))                    
                    }                      
                                
                </div>                      
                 
                </div>

                </center>
                               
                </div>

                <div>
                    <Modal2 
                        open2={isOpen2} 
                        onClose2= {onClose2}
                        children = {videos} 
                        stage= '2' 
                        newWindow = {newWindow} 
                        showBtn = {showBtn}        
                        >
                    </Modal2>
                </div>
                
            </div>
        </div>
    );
}

export default React.memo(Stage2);