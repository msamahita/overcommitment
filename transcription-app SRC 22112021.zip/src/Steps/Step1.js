import React from 'react';
import './Step1.css';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';

import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Cookies from 'js-cookie';

import Modal from '../Modal';

function Step1({setGoNext, setIsDisabled}) {

    const [isOpened, setIsOpened] = React.useState(false);
    const [value, setValue] = React.useState('');
    const [inputValue, setInputValue] = React.useState('');

    React.useEffect(() => {
        Cookies.remove('Categories');  
    }, []);

    React.useEffect(()=>{
      setGoNext(false);
    },[]);
    
    React.useEffect(() => {
      setGoNext(inputValue !== '' ? true : false);
    }, [inputValue]);

    const handleChange = (event) => {      
      setValue(event.target.value)
        
        if(event.target.value === 'yes') {
            setIsDisabled(true) ;
            setIsOpened(false);
            localStorage.setItem('AcceptParticpation', true);
            localStorage.setItem('Com', Math.floor(Math.random() * 2) + 1);                      
          }
        else 
         {
            setIsOpened(true);
            setIsDisabled(false) ;                       
            localStorage.setItem('AcceptParticpation', true);
        }         
      };
  
    const handleChangeValue = (event) => {
          setInputValue(event.target.value);
          localStorage.setItem('ProlificID', event.target.value);
          
          if(event.target.value === ''){
            setIsDisabled(true) ;            
          }
          else{
            setIsDisabled(true) ;            
          }
        };

    const useStyles = makeStyles((theme) => ({
        root: {
          '& > *': {
            margin: theme.spacing(1),
            width: '25ch'
          },
        },
      }));

    const classes = useStyles();

    const msgText = <p>As you do not wish to participate in this study, please return your submission on Prolific by selecting the '<b>Stop without completing</b> button.</p>;    

    const onKeyDown = (event) => {
      if (event.keyCode === 13) { //13 is the key code for Enter
        event.preventDefault()
        //Here you can even write the logic to select the value from the drop down or something.
      }else if(event.keyCode === 110) 
      {
        event.preventDefault();
      }
    }  
        
    return (
        <div className="step1__content">
                    
            <p> 
              <h3><b>Welcome!</b></h3>
              This is a study about decision-making conducted by researchers at University College Dublin and the University <br />of Gothenburg. The study has been given ethical approval by the university's ethics committee. You must be at<br /> least 18 years of age to participate in this study.</p>

            <p>The study will take around 45 minutes to complete. Participation involves completing a simple task and answering<br /> an online questionnaire. All of your responses will remain anonymous throughout and only aggregate results<br /> will be published.
            </p>
            
            <p>The study does not involve any risk of harm. In addition to your participation fee, you may receive additional bonus<br /> payment depending on the decisions you make. If you wish to withdraw at any point during the study, you can simply <br />close your internet browser. Please note that you need to complete the entire session to receive payment <br />for your participation.
            </p>
            <p>If you have any questions regarding this study, please email <a className="step1__email" href="mailto:margaret.samahita@ucd.ie" >margaret.samahita@ucd.ie</a>
            </p>           

            <p>I have read and understood the above and want to participate in this study.</p>
            <div className="Step1">
                <FormControl>     
                    <RadioGroup className="step1__content__MuiFormGroup-root" aria-label="gender" name="gender1" value={value} onChange={handleChange}>
                    <FormControlLabel value="yes" control={<Radio />} label="Yes" />
                    <FormControlLabel value="no" control={<Radio />} label="No" />
                    </RadioGroup>
                </FormControl>
            </div>
            {value === 'yes' ?  (
              <>
              <p>What is your Prolific ID?
              </p>
            <form className={classes.root} noValidate autoComplete="off">
                    <TextField id="standard-basic" value={inputValue} onChange= {handleChangeValue} required onKeyDown = {onKeyDown} />
                    </form>
              </>
            )
            : ''}   
            
            <center>            
            <Modal 
            open ={isOpened} 
            onClose={() => setIsOpened(false)}>
            {msgText}
            </Modal>
        </center>     

    </div>
    );
}

export default React.memo(Step1);