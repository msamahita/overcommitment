import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';

function Step8({setGoNext, setIsDisabled}) {

      React.useEffect(()=>{
        setGoNext(false);
      },[]);

      const [inputValue, setInputValue] = React.useState();  

      const handleChangeValue = (event) => {
        
        if(event.target.value >= 0) 
          {
            setGoNext(true);
            setInputValue(event.target.value);   
            localStorage.setItem('ExpectedCorrectSubmissions1', event.target.value);         
          }
        else 
          {
            setGoNext(false);
          }
      };

        const useStyles = makeStyles((theme) => ({
            root: {
              '& > *': {
                margin: theme.spacing(1),
                width: '25ch'
              },
            },
          }));
        const classes = useStyles();

        const onKeyDown = (event) => {
      if (event.keyCode === 13) { //13 is the key code for Enter
        event.preventDefault()
        //Here you can even write the logic to select the value from the drop down or something.
      }else if(event.keyCode === 110) 
      {
        event.preventDefault();
      }
    }

    return (
        <div>
          <br /><br /><br /><br /><br /><center>
            <p>Suppose that now you are to repeat the transcription task again.
</p><br/><br/>
<p>This second time, how many correct submissions would you expect to get in 15 minutes?</p><br/>

<form className={classes.root} noValidate autoComplete="off">
    <TextField type="text" id="standard-basic" value={inputValue} onChange= {handleChangeValue} onKeyDown= {onKeyDown} />
    </form>
    </center>

    </div>
    );
}

export default React.memo(Step8);
