import React, {useEffect} from 'react';
import './Step17.css';

function Step17({setIsDisabled}) {

    const [isVisible, setIsVisible] = React.useState(true);
    const [makeBottomVisible, setMakeBottomVisible] = React.useState(false);

    useEffect(() => {
            setIsDisabled(false);
            setIsVisible(true);       
            setMakeBottomVisible(false);   
            
            const timer = setTimeout(() => {
                if(Math.random() < 0.50) {
                    localStorage.setItem('CoinToss2', 'HEADS');  
                    localStorage.setItem('RandomGeneratedNumber2', 0); 
                    
                } 
                else
                {

                    localStorage.setItem('CoinToss2', 'TAILS');  
                    localStorage.setItem('RandomGeneratedNumber2', Math.floor(Math.random() * 100)+1); 
                }      
                
                setMakeBottomVisible(true);
                setIsDisabled(true);
                setIsVisible(false);
                
            }, 3000);   

            return () => clearTimeout(timer);
      }, []);

    return (
        <center>
            <div className="step17__content">

            <h4>Now we will tell you the result of your actual transaction.</h4>            
            <span>The price you stated is</span><br />
            <span><b>{localStorage.getItem('RevisedRoundPrice')}</b></span>
            <br />

            <p>The coin toss resulted in</p>

            <h3><b>{localStorage.getItem('CoinToss2')}</b></h3>
            
            {!makeBottomVisible ? ("...") 
            : 
            (
            <>
            <p>Therefore, your test price will {localStorage.getItem('CoinToss2') === 'HEADS' ? 'NOT' : ''} be taken into account</p>

            {
                localStorage.getItem('CoinToss2') === 'HEADS' ? ('') : (
                 <>
                    <p>Given that the coin flip came up TAILS, your chance of removing the YouTube videos is now <br />
                         <b>{localStorage.getItem('RevisedRoundPrice')}%</b></p>
                 </>
            )
            }   

{
                localStorage.getItem('CoinToss2') === 'HEADS' ? ("") : (
                 <>
                    <p> {isVisible ? `Drawing a random number … ` : ''} </p>  
                 </>
            )
            }

            {
                localStorage.getItem('CoinToss2') === 'HEADS' ? ("") : (
                 <>
                    <p> {isVisible ? '' : `The random number drawn is `} <br /><b>{isVisible ? '' :  localStorage.getItem('RandomGeneratedNumber2')}</b></p>
                </>
            )
            } 
            {
            !isVisible ? 
            
            (
                <>
                {localStorage.getItem('CoinToss2') === 'HEADS' ? (<br />) : ("")}  <p>The outcome for the next stage is</p>
                <p><b>Transcription Task
                {localStorage.getItem('CoinToss2') === 'HEADS' ?
                (" WITH ") 
                : 
                (
                    Number(localStorage.getItem('RevisedRoundPrice')    ) >= Number(localStorage.getItem('RandomGeneratedNumber2')) ? (" WITHOUT ") : (" WITH ")
                )
                }
                Youtube videos</b></p><br />
                </>  
            )
            :            
            ("")
            
            }
            
            <p><b>CLICK NEXT TO START STAGE 2</b></p>            
            </>
            )
            }   
            
        </div>
        </center>
    );
}

export default React.memo(Step17);