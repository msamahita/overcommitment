import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import { green } from '@material-ui/core/colors';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import { makeStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import './Category.css';

function Category({element}) {

    const [isChecked, setIsChecked] = React.useState(false);
    
    const GreenCheckbox = withStyles({
        root: {
          color: green[400],
          '&$checked': {
            color: green[600],
          },
        },
        checked: {},
      })((props) => <Checkbox color="default" {...props} />);
           
    const handleChange = (event) => {
            setIsChecked( event.target.checked );
        };
      
    return (
        <div>           
                <Grid container spacing= {2} className="category">                
                {element.map((tile) => (
                
                <FormControlLabel
                    control={<GreenCheckbox checked={isChecked} onChange={handleChange} name="checkedG" />}
                    label={tile} />                     
                      ))}     
                      
                </Grid>
      
      {/* <FormControlLabel
                control={<GreenCheckbox checked={isChecked} onChange={handleChange} name="checkedG" />}
                label={element} /> */}
        </div>
    );
}

export default Category;
