import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import './Step12.css';

function Step10({setGoNext, setIsDisabled}) {

    const [inputValue, setInputValue] = React.useState();
    const [errorValue, setErrorValue] = React.useState('');

    React.useEffect(()=>{
      setGoNext(false);
    },[]);
  
    const handleChangeValue = (event) => {
        if(event.target.value >= 0 && event.target.value <= 100){
            setInputValue(event.target.value.replace(/[^0-9]/g, ''));            
            setErrorValue('');
            setGoNext(true);
            localStorage.setItem('PracticeRoundPrice', event.target.value);
        }
        else {
            setErrorValue('Number must be between 0 and 100');
            setGoNext(false);
        }
        };

        const useStyles = makeStyles((theme) => ({
            root: {
              '& > *': {
                margin: theme.spacing(1),
                width: '25ch'
              },
            },
          }));
    
          const classes = useStyles();

          const onKeyDown = (event) => {
            if (event.keyCode === 13) { //13 is the key code for Enter
              event.preventDefault()
              //Here you can even write the logic to select the value from the drop down or something.
            }
            else if(event.keyCode === 110) 
            {
              event.preventDefault();
            }
          }

        return (
          <div>
          <br />
          <br />
          <br />
          <br />
          <center>
          <p><b>PRACTICE round</b></p>

          <p><b>Maximum TEST price for removing YouTube videos
          </b></p>

          <p>State a TEST price, in cents, you are willing to pay to remove the YouTube videos.<br /> Please enter a number between 0 (cents) and 100 (cents) (inclusive):</p>

          <form className={classes.root} noValidate autoComplete="off">
          <TextField
                    id="standard-number"         
                    type="text"          
                    InputLabelProps={{
                      shrink: false,
                    }}
                    error= {errorValue}
                    value={inputValue}
                    defaultValue=""
                    onChange= {handleChangeValue}
                    onKeyDown = {onKeyDown}          
                  />       
                  
              </form>
              </center>
                  </div>
          );
}

export default React.memo(Step10);
