import { Button } from '@material-ui/core';
import React from 'react';
import './EndQuestionnaire3.css';

import {firebaseApp} from '../firebase';

function EndQuestionnaire3() {

    const db = firebaseApp.firestore();
    
    let date2 = new Date();

    const [isDisabled, setIsDisabled] = React.useState(false);

    React.useEffect(() => { 

        localStorage.setItem('endedTime', date2);                
        let date1 = Date.parse(localStorage.getItem('startedTime'));
        let resultTime = Math.ceil(getDifferenceInSeconds(date1, date2)) - 1;  
        localStorage.setItem('sessionTime', resultTime);        
        
    }, []);    

    function getDifferenceInSeconds(date1, date2) {
        const diffInMs = Math.abs(date2 - date1);
        return diffInMs / 1000;
    }

    const handleClick = () => {        
        setIsDisabled(true);
        saveRecords();        
    };

    const numberFormat = (value) =>
        new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
    }).format(value)

    const saveRecords = () => {

        db.collection('transcriptions')
        .add({
        AcceptParticpation: localStorage.getItem('AcceptParticpation'),
        ProlificID: localStorage.getItem('ProlificID'),
        Categories: localStorage.getItem('Categories'),
        TranscribedCount: localStorage.getItem('TranscribedCount'),
        TranscribedCount2: localStorage.getItem('TranscribedCount2'),
        TranscribedCount3: localStorage.getItem('TranscribedCount3'),
        PaymentStage: localStorage.getItem('Com'),
        CorrectedAnswers1: localStorage.getItem('CorrectedAnswers1'),
        Tasks1: localStorage.getItem('Tasks1'),
        ExpectedCorrectSubmissions1: localStorage.getItem('ExpectedCorrectSubmissions1'),
        PracticeRoundPrice: localStorage.getItem('PracticeRoundPrice'),
        CoinToss1: localStorage.getItem('CoinToss1'),
        RandomGeneratedNumber1: localStorage.getItem('RandomGeneratedNumber1'),
        PreferredYoutubeThumbnails: localStorage.getItem('PreferredYoutubeThumbnails'),
        ActualRoundPrice: localStorage.getItem('ActualRoundPrice'),
        ExpectedCorrectSubmissions2: localStorage.getItem('ExpectedCorrectSubmissions2'),
        LikelyClickOnThumbnails: localStorage.getItem('LikelyClickOnThumbnails'),
        DoClickExpectedCorrectSubmissions3: localStorage.getItem('DoClickExpectedCorrectSubmissions3'),
        DoNotClickExpectedCorrectSubmissions3: localStorage.getItem('DoNotClickExpectedCorrectSubmissions3'),
        TemptedClick: localStorage.getItem('TemptedClick'),
        RevisedRoundPrice: localStorage.getItem('RevisedRoundPrice'),
        CoinToss2: localStorage.getItem('CoinToss2'),
        RandomGeneratedNumber2: localStorage.getItem('RandomGeneratedNumber2'),
        CorrectedAnswers2: localStorage.getItem('CorrectedAnswers2'),
        Tasks2: localStorage.getItem('Tasks2'),        
        DurationView: localStorage.getItem('DurationView'),
        DurationView2: localStorage.getItem('DurationView2'),
        LeftTimesMainTab: localStorage.getItem('LeftTimesMainTab'),
        LeftTimesMainTab2: localStorage.getItem('LeftTimesMainTab2'),
        Age: localStorage.getItem('Age'),
        Gender: localStorage.getItem('Gender'),
        SpendTimeOnYoutube: localStorage.getItem('SpendTimeOnYoutube'),
        Option1: localStorage.getItem('Option1'),
        Option2: localStorage.getItem('Option2'),
        Statement1: localStorage.getItem('Statement1'),
        Statement2: localStorage.getItem('Statement2'),
        Statement3: localStorage.getItem('Statement3'),
        Statement4: localStorage.getItem('Statement4'),
        Statement5: localStorage.getItem('Statement5'),
        Statement6: localStorage.getItem('Statement6'),
        Statement7: localStorage.getItem('Statement7'),
        Statement8: localStorage.getItem('Statement8'),
        Statement9: localStorage.getItem('Statement9'),
        Statement10: localStorage.getItem('Statement10'),
        Statement11: localStorage.getItem('Statement11'),
        Statement12: localStorage.getItem('Statement12'),
        Statement13: localStorage.getItem('Statement13'),
        Earnings: localStorage.getItem('Earnings'),
        CostOfRemoving: localStorage.getItem('CostOfRemoving'),
        TotalBonus: localStorage.getItem('totalBonus'),
        MyExperienceComment : localStorage.getItem('MyExperienceComment'),
        startedTime: localStorage.getItem('startedTime'),
        endedTime: localStorage.getItem('endedTime'),
        startedTask1: localStorage.getItem('startedTask1'),
        sessionTimeTask1: localStorage.getItem('sessionTimeTask1'),
        startedTask2: localStorage.getItem('startedTask2'),
        sessionTimeTask2: localStorage.getItem('sessionTimeTask2'),
        sessionTime: localStorage.getItem('sessionTime'),

        durationview2YTPractice: localStorage.getItem('durationview2YTPractice'),
        durationview3YTPractice: localStorage.getItem('durationview3YTPractice'),
        durationview2YT: localStorage.getItem('durationview2YT'),
        durationview3YT: localStorage.getItem('durationview3YT'),
        
        ClickedThumbnailsTab: localStorage.getItem('ClickedThumbnailsTab'),
        ClickedThumbnailsTabPopUp: localStorage.getItem('ClickedThumbnailsTabPopUp'),
        ClickedThumbnailsTabPractice: localStorage.getItem('ClickedThumbnailsTabPractice'),
        ClickedThumbnailsTabPopUpPractice: localStorage.getItem('ClickedThumbnailsTabPopUpPractice'),
        durationPopupShownTask1:localStorage.getItem('durationPopupShownTask1'),
        durationPopupShown:localStorage.getItem('durationPopupShown')

        });

        const timer = setTimeout(() => {
            window.open('https://app.prolific.co/submissions/complete?cc=81E5FDC9', '_self');   
            setIsDisabled(false); 
            
        }, 3000);   
        return () => clearTimeout(timer);
        
    }

    return (
        <div className="EndQ3__content">
            <center>
            
            <p><b>Stage chosen for payment</b></p>

            <span>Stage {localStorage.getItem('Com')}</span><br />

            <p><b>Number of correct submissions in that Stage</b></p>
            <span>{localStorage.getItem('Com') === '1' ? (localStorage.getItem('CorrectedAnswers1')) : (localStorage.getItem('CorrectedAnswers2'))}</span><br />

            <p><b>Earnings from correct submissions</b></p>
            <span>{numberFormat(localStorage.getItem('Earnings'))} </span><br />

            <p><b>Cost of removing YouTube videos</b></p>
            <span>{numberFormat(Number(localStorage.getItem('CostOfRemoving'))) } </span><br />

            <p><b>Total bonus payment</b></p>
            <span>{numberFormat(localStorage.getItem('totalBonus'))}</span><br />

            <p><h5><b><font color="#3f51b5">Please click RETURN TO PROLIFIC to record the completion of this study.</font></b></h5></p>

            <Button variant="contained" color="primary" onClick ={handleClick} disabled = {isDisabled} >
                RETURN TO PROLIFIC
            </Button>    
                       
            </center>            
        </div>
    );
}

export default React.memo(EndQuestionnaire3);