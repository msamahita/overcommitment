import React from 'react';
import ReactDom from 'react-dom';
import Button from '@material-ui/core/Button';

import './Modal2.css';
import tmpbg from './pics/tmpbg.png';
import YouTube from 'react-youtube';

function Modal2({ open2, children, onClose2, stage, newWindow , showBtn}) {
    
    React.useEffect(() =>{
        if(showBtn === 'none'){
            if(document.getElementById('textzone') && document.getElementById('textzone').style !== null){
            document.getElementById('textzone').style.display = 'none';
            document.getElementById('close').style.display = 'none';
            } 
            if(document.getElementById('blockoverlay') && document.getElementById('blockoverlay').style !== null)
            document.getElementById('blockoverlay').style.display = 'block';
        }
        else {
            if(document.getElementById('textzone') && document.getElementById('textzone').style !== null){
            document.getElementById('textzone').style.display = 'block';
            document.getElementById('close').style.display = 'block';
            } 
            if(document.getElementById('blockoverlay') && document.getElementById('blockoverlay').style !== null)
            document.getElementById('blockoverlay').style.display = 'none';
        }
    }, [showBtn])

    const MODAL_STYLE = {
        position: 'fixed',
        top: '7%',
        left: '1%',
        right: '1%',
        bottom: '1%',
        width : '98%',
        height: 'auto',
        transform: 'translate (-50%)',
        backgroundColor: '#464F52',
        padding: '2px',
        zIndex: 1000
    }

    const OVERLAY_STYLE = {
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0,0,0,.705)',
        zIndex: 1000
    }

    const BTN_STYLE = {
        position: 'absolute',
        right: '10px',
        bottom: '5px',
        fontWeight: 'bold',
        fontSize: '12px',
        color: '#D98880',
        display: 'none',
        fontFamily: 'Lucida Sans'
    }

    if (!open2) return null;
        
    const getVideo = (e, videoId) => {
        e.preventDefault();

        if(stage === '2') {
            let n = Number(localStorage.getItem('ClickedThumbnailsTabPopUp'));
            n= n + 1;
            localStorage.setItem('ClickedThumbnailsTabPopUp', n);
        }
        else {
            let n = Number(localStorage.getItem('ClickedThumbnailsTabPopUpPractice'));
            n= n + 1;
            localStorage.setItem('ClickedThumbnailsTabPopUpPractice', n);
        }

        if(stage === '1') 
            newWindow.current = window.open("/youtubeplayer?videoId=" + videoId +"&mode=pop&loader=practice", "_blank");

        else newWindow.current = window.open("/youtubeplayer?videoId=" + videoId +"&mode=pop&loader=stage2", "_blank");
        
        onClose2();
    };

    const opts = {
        height: '640',
        width: '100%',
        playerVars: {
          // https://developers.google.com/youtube/player_parameters
          autoplay: 1,
          controls: 0,
          playsinline: 1
        },
    };
            
    const _onReady = (event) => {  
        event.target.playVideo();                
    }

    const _onStateChange = (event) => {
              
      if (Number(event.data) < 0) {
        //alert('-Auto play Video/Audio Option is disabled!\n-Can not play automatically the video\n-Please enable it from browser settings.');
      }       
        
    }

    const onClosePopup = () =>{
        onClose2();
    }
    
    return ReactDom.createPortal(
        
        <>
        <div>
            
            <div style={OVERLAY_STYLE}></div>            
            <div className="ignoreClass" style={MODAL_STYLE}>                   

                        <div className="modal_header">
                        
                        <Button id="close" style={BTN_STYLE} color="secondary" onClick={() => onClosePopup()}>Close</Button>
                        
                        </div>  

                        <center>
                            <div className="blockoverlay" id="blockoverlay">
                            
                            </div>

                            <div className="modal_button">
                                
                                {                                    
                                    children.length > 0 && children.slice(0,1).map((photo, index) => (            
                                        <> 
                                        
                                        {index === 0 ? (<div className="topShowModal">
                                        
                                        {index ===0 ? (
                                        <div className="divOverlap" >
                                        <span className="colorTitle">
                                            {photo.Title}
                                        </span>
                                        <YouTube 
                                        videoId = {photo.VideoId}
                                        opts={opts}
                                        onReady={_onReady}
                                        onStateChange = {_onStateChange}

                                        />

                                        <img 
                                        alt=""  
                                        className="overlay"
                                        src={tmpbg} 
                                        onClick= {(e) => getVideo(e, photo.VideoId)}
                                        />

                                        </div>

                                        ) 
                                        : 
                                        ("")
                                        }
                                        </div> 
                                        ) : ("")                                   
                                        
                                        }                                                    
                                        </>                      
                                    ))                                    
                                }
                                                                 
                            </div> 
                        </center>
                        
                        <div className="modal_bottom">
                                <center>
                                <p id= "textzone" className="titleAbove">Close this pop-up to return to the transcription task.</p>
                                </center>
                        </div>                
                                        
                </div>
        </div>        
        </>
        ,    
        document.getElementById('portal')
    );
}

export default React.memo(Modal2);