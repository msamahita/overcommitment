// const CLIENT_ID = '';
// const DISCOVERY_DOCS = '';
// const SCOPES = '';

// const authorizeButton = document.getElementById('authrize-button');

// const signoutButton = document.getElementById('signout-button');

// const gapi = new gapi();

// // load auth2 lib

// function handleClientLoad() {
//     gapi.load('client:auth2', initClient);
// }

// // Init API client
// function initClient() {
//     gapi.client.init(
//         {
//             discoveryDocs: DISCOVERY_DOCS,
//             clientId: CLIENT_ID,
//             scopes: SCOPES
//         }
//     ).then(() => {
//         gapi.auth2.getAuthInstance().isSignedIn.listen(updateSigninStatus);
//     });
// }

// // Update uI

// function updateSigninStatus(isSihnedIn) {
//     if (isSihnedIn) {
//         authorizeButton.style.display = 'none';
//         signoutButton.style.display = 'block';

//     } else {
//         authorizeButton.style.display = 'block';
//         signoutButton.style.display = 'none';
//     }
// }

// // Handle click
// function handleClick() {
//     gapi.auth2.getAuthInstance().signIn();
// }

// function handleSignoutClick() {
//     gapi.auth2.getAuthInstance().signOut();
// }